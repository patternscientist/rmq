# LB1-BLIND independent exact-commit audit

Status: CANDIDATE_COMPLETE  
Audit verdict: INCOMPLETE

The status token records completion of this auditor’s report, not implementation acceptance.

## Findings

- **P0:** No demonstrated correctness or trust-base defect.
- **P1-REPLAY-RESOURCE:** The mandatory `S03-SIBLING-BUDGET` control is inconclusive. `RMQ/Validation/VariablePayloadLowerBound.lean:57` requires:

  `P = ∀ n B, UniformAllocationBudget n B → shapeCount n ≤ 2^(B+1)-1`.

  `scripts/variable_payload_replay.ps1:389` substitutes:

  `Q = ∀ n B, UniformAllocationBudget n B → shapeCount n ≤ 2^(2*n+allocationRho n+1)-1`.

  The modified producer exited zero. The consumer exited one with only “maximum recursion depth has been reached” at line 57, after 16.226 seconds. The runner correctly rejected this resource outcome at `scripts/variable_payload_replay.ps1:199`. The campaign therefore stopped after 60 successful cases; `H01-EMPTY-ONLY-DECODER` and `A02-PROOF-ONLY-WRAPPER` were unexecuted.

  The smallest repair is to make this exact consumer reject the mismatched proposition without resource exhaustion, preserving P and Q, followed by a complete replay on the repaired final target. Restricting proof elaboration transparency is a possible repair to test, not an established fix. This is a mandatory verification failure, not a demonstrated false lower-bound theorem.
- **P1-EVIDENCE-MODES:** Separate exact-target outcomes for all five required focused entry points are unprovided: `-RegistryOnly`, `-SelectorBoundaryOnly`, `-DiagnosticOnly`, `-DeadlineOnly`, and `-RuntimeOnly`. Historical records and internally invoked components were inspected, but one mode’s execution does not establish another mode’s invocation.
- **P1-EVIDENCE-FINAL:** Coordinator build/aggregate certification and report-sensitive final-tree checks are unprovided. `docs/internal/extensions/lb1/CONTRACT.md:107` assigns aggregate certification to the coordinator. The frozen audit prompt at lines 408–422 also requires strict claim drift, applicable strict design checking, and whitespace checks on the report-containing durable tree. The user confirmed that the coordinator will supply these results.
- **P2:** No separate demonstrated model-scope or documentation defect. Platform and evidence limits are recorded below.
- **P3:** No polish-only repair requested.

The original target is not ready for a positive final audit verdict. A repaired target requires its own fresh exact-commit audit.

## Identity, independence and ownership

Auditor: **LB1-BLIND**, FRESH BLIND DELTA.

- Target: `d6dabbec10648f368df9ddcd32102f84deffb281`.
- Delta base and workflow governance: `0e6a00f654abc64f8b68988fa9675b9a839dca2f`.
- Frozen-contract checkpoint: `0bbbe8ca4a937bc9782b2f7c5cc5419faa1a75a2`.
- Branch label: `codex/lb-1-variable-payload`.
- Isolated checkout: `C:/Users/poin/.codex/worktrees/2270/RMQ/.lake/lb1-final-audit/checkout`.

Every shell invocation explicitly used that checkout. Exact Git blobs supplied the source under audit; the parent replay’s changing working files did not substitute for them. The checkout remained clean at the exact target in the final auditor check.

The frozen prompt was the first file read. Its SHA256 is:

`680F459BE11666ABA9C9833DDD61EAB0D30530251CDA7574FFBBA0538691CBD1`.

Only allowlisted immutable source, scoped public addenda, and neutral command artifacts were inspected. Worker completion narratives, previous reviews/verdicts, withheld design/process narratives, and chat transcripts were not read. Coordinator progress messages were scheduling and provenance notices, not semantic evidence.

The actual runtime RMQ catalog was:

`rmq-audit-prompt,rmq-coordinator,rmq-proof-sprint`.

Applicable required audit-worker role skills were **NONE**. This command passed:

```powershell
& scripts/project_skill_preflight.ps1 `
  -GovernanceRef 0e6a00f654abc64f8b68988fa9675b9a839dca2f `
  -AllowNoRequiredSkills `
  -RuntimeProjectSkills 'rmq-audit-prompt,rmq-coordinator,rmq-proof-sprint'
```

No `RequiredSkills` argument was supplied. The complete canonical checkout and governance ancestry passed. Git warned that the user ignore configuration was inaccessible; explicit worktree/index/untracked checks were still performed.

The higher-priority proof-auditor role says **“Do not edit files.”** The coordinator accepted that constraint and changed report transport only. The auditor returns this complete text; the coordinator owns saving it verbatim at:

`C:/Users/poin/.codex/worktrees/2270/RMQ/.lake/lb1-final-audit/REPORT.md`

and later copying it to:

`docs/internal/extensions/lb1/FINAL_AUDIT.md`.

The auditor wrote neither file and made no source, artifact, or Git-state changes. No Lean, Lake, runtime, mutation, or aggregate command was run by the auditor.

## Evidence tiers and source notation

The following tiers remain distinct:

- **K:** Kernel theorem and its explicit proof dependencies.
- **M:** Explicit theorem about the declared model, store, trace, or execution.
- **E:** Actual executable validation.
- **R:** Reproducible committed source, registry, controls, and hash-reconciled artifacts.
- **P:** Process outcome, ownership, deadline, restoration, or clean-state record.

A process record alone does not establish a semantic theorem. Runtime examples do not establish universal exactness. Axiom output does not establish public dependency under mutation.

Source abbreviations, always at the exact target:

- **G:** `RMQ/Core/EncodingVariableLowerBound.lean`.
- **A:** `RMQ/Core/WordRAM/Packed/AllocationLowerBound.lean`.
- **V:** `RMQ/Validation/VariablePayloadLowerBound.lean`.
- **Replay:** `scripts/variable_payload_replay.ps1`.
- **Owned:** `scripts/owned_process_tree.ps1`.
- **Shape:** `RMQ/Core/Shape.lean`.
- Other short packed-module names refer to `RMQ/Core/WordRAM/Packed/<Name>.lean`.

Positive source assertions below use K/M through their literal consumers and the checked baseline, R through the exact target and committed controls, and E only where actual runtime controls are named. Mandatory evidence gaps remain explicit.

## Semantic reconstruction

G:124–130 defines exactly four fields:

```lean
encode : List Int → List Bool
query : List Bool → Nat → Nat → Option Nat
length_le : ∀ xs, xs.length = n → (encode xs).length ≤ B
query_exact : ∀ xs, xs.length = n →
  ∀ left len, 0 < len → left + len ≤ n →
    query (encode xs) left (left + len) = some (scanWindow xs left len)
```

One fixed decoder handles every size-n input. Length is observed. The interface assumes neither injectivity nor prefix freedom. G:23–25 and G:61–117 enumerate every bitstring length from zero through B, prove no duplicates, and prove cardinality `2^(B+1)-1`.

Equal codes imply equal valid-window answers; the Cartesian discriminator gives equal shapes. Representatives then yield the finite-shape injection at G:137–184. G:187–211 derives the count and:

```lean
EncodingLowerBound.doubledLogSlackLower n ≤ 2 * (B + 1)
```

The predecessor doubled term is the Nat-truncated expression:

`4*n - (3*Nat.log2 (2*n+1)+3)`.

G:214–260 supplies an input witness for every n and actual empty/singleton encoding witnesses.

A:23–69 serializes arbitrary finite bounded word lists and proves exact length, left inverse, and injection at positive width. Different multiplicities of zero words retain different observed lengths. Width zero is explicitly excluded.

The executable chain at A:72–81 is:

```lean
allocationBits xs =
  serializeWords (wordWidth xs.length) (buildMemory xs)

allocationDecoder n bits left right =
  queryNat (deserializeWords (wordWidth n) bits) n left right

reconstructedMemory xs =
  deserializeWords (wordWidth xs.length) (allocationBits xs)
```

A:87 proves recovery of the entire actual allocation, before querying. Metadata and final padding remain included. The decoder captures n only, with no xs, shape, answer, or proof argument.

A:155 defines:

```lean
UniformAllocationBudget n B :=
  ∀ xs : List Int, xs.length = n →
    (buildMemory xs).length * wordWidth n ≤ B
```

A:159–202 instantiates the generic encoding with the actual allocation, derives arbitrary-B and canonical bounds, and compares the same allocation with its per-input `2*n+allocationRho n` upper capacity.

A:206 establishes identical runs for arbitrary fuel. A:316–399 transports the 33 machine fields through exact memory equality. A:401–458 packages them with the 16 optimality fields. V:256–273 and V:372–377 explicitly compose the lower theorem, actual encoding/decoder, serialized length, recovery, and upper bound.

The operational dependency is concrete: `buildMemory` contains metadata and the complete repacked allocation; the fixed program loads metadata; primitive loads update registers from numeric memory; select/LCA/rank consume reader-produced values; halt reads the result register. `ReaderCorrect` and `PhysicalRead` constrain actual output registers as well as receipts.

Raw-machine result and safety theorems retain both endpoint representability guards. The total Nat wrapper handles arbitrary endpoints, and valid ranges imply representability. Those facts are not interchangeable.

The model counts scalar primitive transitions, indexed memory operations, code, and scratch under one n-linked word width. It does not establish Lean host runtime, charged bit-conversion time, preprocessing time, cost attainment, or impossibility of a smaller upper bound.

## Independent map of all 29 frozen requirements

Each quoted requirement is verbatim from the frozen row.

### REQ-LB-COUNT

> Define payload-only exact RMQ encodings by bitstrings of length at most B, allowing length to be observed. Prove the finite cardinal bound 2^(B+1)-1 and shape injectivity from valid half-open leftmost answers. Derive the coefficient-correct doubled Catalan lower bound at 2*(B+1), or a strictly sharper bound proved from the same model.

G:124–130 fixes the universal length/exactness interface. G:23–25 and G:61–117 provide the complete bounded universe. G:137–211 derives behavior equality, shape equality, representative injection, count, and doubled lower bound. Shape:146–151 and Shape:583–589 supply the half-open semantic discriminator. G:214–260 witnesses all input sizes and n=0,1.

Consumers include `genericCardinalConsumer`, `genericShapeCountConsumer`, `genericLowerConsumer`, `genericBoundConsumer`, and `genericExactnessConsumer`. G01/G02 have their required observed outcomes. Fixed-decoder, null/wrong-answer, and zero-budget theorem controls use the same exactness domain.

**Disposition:** K/M source and named local controls supported. Final coordinator certification remains pending.

### REQ-LB-PQ1

> Serialize the actual PQ1 buildMemory cells at wordWidth n, fixed for each n, and prove serialization injective on finite word lists with entries below 2^wordWidth(n), allocation encoding injective on size-n Cartesian shapes, and the decoder's exact RMQ contract using only serialized cells, n, endpoints and n-only fixed advice. The decoder must not retain xs or an uncounted shape. Distinct List Int inputs with the same shape intentionally share memory: no value-list injectivity is asserted. Address variable allocation length explicitly; plain zero padding is not injective.

A:23–69 handles arbitrary finite bounded word lists at positive width. A:72–96 joins actual bits, deserialization, exact `buildMemory` recovery, and `queryNat_exact`. A:106–151 proves intended sharing and shape injection. V:306–331 pins executable definitions and encoding projections.

O01–O08, runtime R01–R06, D01–D03, F01, and S01 are observed controls of these links. H01 is committed but unexecuted.

**Disposition:** INCOMPLETE for required control coverage because H01’s domain-restriction rejection is missing; the source construction and observed controls are supported.

### REQ-LB-MODEL

> Prove a worst-case-over-inputs lower bound on a uniform allocation budget and a two-sided comparison with the actual PQ1 2n+rho(n) allocation. Separate payload, fixed code, scratch and external n/advice conventions. Do not equate a fixed-length encoding with a variable-length one or assert the lower bound for every individual input.

A:155–180 defines one budget over every size-n input and the arbitrary/canonical instances. A:182–202 applies the generic lower bound to the actual allocation and supplies its upper capacity. A:216–225 and V:99–107 separate payload from code/scratch.

O09–O14, M01–M05, and `composedConsumer` pin the chain. S03 tests replacing the arbitrary-B conclusion with the canonical one.

**Disposition:** INCOMPLETE. P is supported by K/M and baseline consumers, but S03 exhausted recursion instead of producing an admissible semantic rejection.

### REQ-LB-CONSUMER

> One checked capstone/typed consumer must compose the generic counting theorem, exact decoder and actual allocation object; independently expand its predicates to exclude vacuous domains and proof-only decoding oracles.

V:256–273 expands budget, decoder validity, bit length, recovery, and upper capacity in one conjunction from `packedAllocationOptimality_holds`. V:372–377 pins the canonical encoder/decoder before consuming its generic lower theorem. G:124–130 and A:76–77 exclude proof arguments from executable decoding; exactness covers every size-n input.

All 49 literal projections and P01/G01/G02 have required observed outcomes.

**Disposition:** INCOMPLETE because S03 is inconclusive and H01/A02 are unexecuted.

### CHK-LB-CONTROLS

> Persist empty/singleton, equal-key/leftmost, all-zero/empty-string collision, null/wrong-answer decoder, deleted exactness, permitted n-only advice and rejected input/shape-dependent advice controls. A mutation must fail the same proposition as the positive theorem, not merely change a surrounding log or a declaration name.

G:242–260 covers empty/singleton and permitted n-only advice. G:263–325 rejects null/wrong/fixed empty-code decoders under universal exactness. `scripts/variable_payload_generic_consumer.lean:38` specializes rejected fixed input/shape advice while retaining all size-two inputs and valid windows.

V:379–419 supplies equal-key, width-zero exclusion, and zero-word multiplicity theorems. R01–R06 execute actual conversions/allocation/decoder with literal or specification-derived expectations. D01–D03/G02 have exact rejection surfaces.

**Disposition:** INCOMPLETE: A02’s required altered proof-only wrapper acceptance was not executed.

### REPLAY-EXACT-REGISTRY

> any new replay must have a nonempty exact versioned case registry and report executed/expected cases; silently losing a case is failure.

Replay:19–93 independently fixes 63 ordered proof/control cases and six runtime IDs, checking JSON version, identity, fields, verdicts, and surfaces. Independent parsing confirmed the exact unique ordered lists. Replay:426–434 requires executed order to equal selected order; omission selects all 63.

**Disposition:** INCOMPLETE: only the first 60 completed successfully; S03 is inconclusive, H01/A02 unexecuted, and no positive full summary exists.

### REPLAY-SELECTOR-NONVACUITY

> omitted, valid, empty, whitespace, malformed and unknown selectors have pinned behavior; focused runs cannot succeed by selecting nothing.

Replay:94–115 distinguishes selector boundaries and rejects CLI/environment duplication. Replay:253–278 defines the six focused subprocess boundaries. V:518–575 validates runtime selectors before constructing fixtures and rejects conflicts at V:543–544.

Current runtime startup, known-selector, four rejected boundaries, and full execution are observed. Conflict handling is source-inspected only. Historical focused selector records are not relabeled exact-target invocations.

**Disposition:** INCOMPLETE: separate exact-target focused-mode provenance remains unprovided.

### REPLAY-SUBPROCESS-DEADLINE

> run subprocesses with bounded ownership/timeout, preserve exits and stderr, restore mutated bytes in finally, and verify exact clean restoration. Use existing process ownership tooling. A condition the host cannot create is uncovered/inconclusive, not passed.

Replay:150–167 uses owned bounded subprocesses and preserves exits/stdout/stderr. Owned:373–428 establishes Windows job ownership before releasing child execution; Owned:273–306 and Owned:447–520 close ownership and wait for known children/root termination.

Replay:323–333 and Replay:428–431 restore exact source/olean bytes and check clean channels. Historical Windows timeout evidence actually created descendant PID 29284; an earlier probe that failed to create the condition remains inconclusive.

**Disposition:** INCOMPLETE for current focused-mode evidence. Original-run restoration has the qualified process evidence described below, not an independent before/after olean-hash comparison. POSIX is unobserved.

### INV-STORE-IDENTITY

> the exact payload/store executed is the payload/store counted by the public space theorem; a theorem about a sibling payload is insufficient;

O03/O04/O13/O15 and M04/M05 state actual serialized length, recovery, capacity, and identical runs. V:315–325 pins executable definitions to `buildMemory`. F01/S01/S02 and the corresponding field weakenings target these links.

A:87 supplies memory identity used to transport the machine certificate.

**Disposition:** K/M source and named local controls supported; final coordinator certification pending.

### INV-VALUE-DEPENDENCY

> returned values and routing decisions depend on actual charged reads, not a semantic answer computed before the reads. When the requirement concerns the returned answer or route, evidence must constrain that value, state, or route; inequality of an enclosing trace record can be satisfied by its log alone and is insufficient;

Primitive:133–153 puts loaded replies in registers and obtains the halted answer from a register; Primitive:194–197 projects that value. Setup:384–393 constrains changed loaded metadata to change the actual destination register under its explicit state/index guards.

PhysicalRead:64–88 constrains actual decoded outputs and receipts for supplied numeric memory and invocation arguments. QuerySource:24–56 routes reader-produced registers through select/LCA/rank. M18/M31 pin the returned answer, while M27/M30 constrain actual execution.

Calculus:345–347 and SpanAssembly:499–503 are supplementary value examples, not universal liveness substitutes.

**Disposition:** K/M source and named local controls supported. No claim that every cell affects every query is inferred.

### INV-SEMANTIC-NONVACUITY

> semantic coverage, liveness, ownership, and refinement predicates are derived from the operational construction they describe. A predicate defined to be `True`, an enumeration restated as membership, or a separately hand-written consumer label does not establish operational liveness by itself;

M24/M27/M28/M31 constrain instruction safety, actual execution, ordered physical expansion, and the actual valid result. ReadInterface:75–84 constrains the actual reader’s destination/length registers and reads at its invocation arguments. PhysicalRead:166–233 proves that interface for canonical numeric memory.

G:214–260 witnesses edge domains. The corresponding True-weakenings reject at literal consumers. M27 alone could be vacuous on an empty trace; M28’s valid-query metadata prefix and M31’s actual answer supply additional constraints.

**Disposition:** INCOMPLETE for required control coverage because H01 is unexecuted; source-derived predicates and observed field controls are supported.

### INV-TRACE-EXECUTION

> traces and footprints are derived from the execution they describe;

Primitive:163–190 derives transitions from fetched `execute` calls and receipts/categories from those transitions. Calculus:143–198 proves occurrence-indexed prefix, instruction, and load provenance. M27 pins each occurrence; M28 preserves ordered expansion and multiplicity. O15 transports identical execution at arbitrary fuel.

**Disposition:** K/M source and corresponding field controls supported; final certification pending.

### INV-STORE-AGREEMENT

> supplied-store agreement determines result, cost, and the relevant trace;

M30 quantifies over xs, supplied memory, and endpoints. Agreement on every attempted receipt address of the recovered-memory run implies equality of the entire supplied-memory `Run`. Calculus:240–262 proves this by execution induction, retaining failed `none` replies in the premise.

Full-run equality fixes result, steps, categories, positions, and final state without supplying a second trace. Calculus:351–356 negates the same agreement premise when a failed address becomes present.

**Disposition:** K/M source and M30/O15 controls supported; final certification pending.

### INV-READ-BACKING

> every successful read is backed positionally by the counted store;

M27 quantifies transition index, transition, and receipt; identifies the prefix pre-state, fetched instruction, and actual execute pair; and supplies the load’s address-register argument and numeric store reply. M26 adds guarded width bounds. M32 establishes no failed loads on valid runs.

F02 deletes the positional field; M27 weakens it. Both reject at `checkM27`.

**Disposition:** K/M source and named controls supported; final certification pending.

### INV-WORD-WIDTH

> stored and returned words fit one declared modeled machine word;

M06 bounds stored recovered words. M23–M26 bound final states, indexed transitions, prefixes, and returned receipt values at `wordWidth xs.length`. M15 establishes valid endpoint representability; raw claims retain both guards.

Primitive:199–213 expands state/instruction safety. O01 retains positive width and bounded word hypotheses.

**Disposition:** K/M source and corresponding controls supported; final certification pending.

### INV-ADDRESS-WIDTH

> every executed address, dead/sentinel address, and encoded instruction operand fits the modeled machine word, not merely the host array bounds. Constructor-exhaustive evidence must include register identifiers, branch/jump targets, dormant code, and arithmetic operands;

M07 includes `address ≤ reconstructedMemory.length`, covering the physical end sentinel. M08 covers every instruction in the fixed program. Primitive:78–108 exhaustively encodes tags, constants, registers, arithmetic operands, jumps, and branch targets, including dormant code.

M24/M26 cover actual operands and receipt addresses at the same width. Logical dead requests can emit no physical load; their metadata and register values remain constrained by M06/M24/M25.

**Disposition:** K/M source and named controls supported; final certification pending.

### INV-INSTRUCTION-ATOMICITY

> each modeled small step performs the familiar primitive operation it advertises. A constructor whose evaluator body hides recursion, a variable-length scan, repeated rank/select work, decoding, or several arithmetic categories is a macro-step unless that work is expanded into charged transitions or bounded by an explicitly accepted primitive;

Primitive:28–63 and Primitive:133–153 implement the declared scalar arithmetic, comparison, load, transfer, branch, and halt operations. Indexed access and scalar div/mod/shift/bitwise operations are accepted model primitives; their Lean implementation runtime is not the theorem.

QuerySource:74–103 connects structured blocks to actual primitive execution and fixed program length. Serialization/deserialization at A:23–30 is outside the charged execution, as disclosed at A:13–15. LB1 adds no macro-instruction.

**Disposition:** K/M source and M21/M22/M24/O15 controls supported within the declared model; final certification pending.

### INV-PROGRAM-ACCOUNTING

> input-dependent constants and metadata carried by executable code are counted machine data or are derived uniformly from counted/public inputs. Calling shape-specialized data "program code" does not remove it from the payload/state accounting obligation;

`queryProgram` is closed at QuerySource:55–60. Guard:18–22 initializes only n/endpoints and zero registers. Setup:15–23 loads all 174 varying metadata cells by charged constant/load pairs. Allocation:154–164 counts metadata and final padding in `buildMemory`.

M05 and M08–M14 count encoded code and finite scratch, and pin unused registers. The canonical decoder captures n only.

**Disposition:** K/M source and named local controls supported; final certification pending.

### INV-ORACLE-INDEPENDENCE

> executable fixtures and edge-case expected values come from an independent specification or a theorem already connected to it, never from the implementation result being tested;

V:467–515 constructs literal inputs inside selected branches. Empty, invalid, singleton, and leftmost expectations are independent literals or `scanWindow` checks. Word roundtrips compare against literal words. Same-shape behavior is connected to the proved sharing theorem.

Serializer consistency alone is an identity test; separate exact-length, recovery, and expected-answer assertions supply semantic checks.

**Disposition:** Source and actual six-case runtime evidence supported; no implementation-derived expected answer was identified.

### INV-VALIDATION-REACH

> executable validation imports and runs the new semantic layer. A validator for the predecessor implementation is regression evidence only and does not validate the new machine;

V:1 imports the new allocation-lower-bound layer. V:456–515 evaluates `allocationBits`, deserialization, and `allocationDecoder`. Selection precedes fixture construction at V:548–572. `lakefile.toml:40` supplies the new executable target.

The current baseline freshly emitted the validation olean before runtime. Actual six-case execution is distinct from list/startup and the known selector.

**Disposition:** Source and current runtime evidence supported; final certification pending.

### INV-ALL-SIZE

> exactness covers all assigned sizes and edge cases without hidden readiness or compatibility dispatch;

G:124–130 ranges over every size-n list and every positive valid window; G:214–216 supplies input witnesses. A:91–103 covers the total Nat wrapper for every xs and endpoints. A:173–180 supplies the canonical budget for every n without readiness dispatch.

Raw safety keeps representability premises; valid ranges discharge them. Empty/singleton witnesses are inhabited. H01 restricts exactness to empty inputs and must fail `checkO05`.

**Disposition:** INCOMPLETE because H01 is unexecuted, despite universal source predicates and checked edge cases.

### INV-PROOF-SEPARATION

> proof-only fields never carry answers or uncharged routing information;

G’s executable fields are encode/query; proof fields assert length and exactness. A:76–81 deserializes numeric cells and calls `queryNat` with no proof/shape argument. Both capstones are Prop structures consumed by theorem proofs.

QuerySource:67–72 and Primitive:133–197 contain no proof-side representative or correctness oracle. A02 adds a private Prop wrapper outside the public records and must preserve producer/inventory/consumer acceptance.

**Disposition:** INCOMPLETE because A02 is unexecuted; executable dependency separation is source-supported.

### INV-NO-SYNTHETIC

> synthetic events, decorative rereads, and post-hoc replay do not support the execution claim;

Actual execution generates transitions; reads are filtered actual receipts, and only load instructions produce receipts. M27 pins occurrence prefixes and producing instructions. M28/M29 combine ordered physical expansion with logical read-only behavior. `ReaderCorrect` constrains actual output registers, not receipts alone.

LB1 adds only the input-memory adapter and run-identity proof; it adds no log generator or execution oracle.

**Disposition:** K/M source and M27–M29 controls supported; final certification pending.

### INV-CATEGORY-SEPARATION

> payload bits, proof fields, model ticks, machine state, Lean runtime, and measured performance remain distinct.

A:6–15 and the scoped public addenda distinguish observed bits, mathematical conversion, and primitive execution. M04/M05 separate data from code/scratch; M21/M22 count actual model transitions/categories. V:367–369 pins `LittleOLinear`.

The bound is at most the fixed budget. It does not establish attainment or forbid a smaller upper bound.

**Disposition:** Source/model separation supported; report-containing-tree strict claim certification remains INCOMPLETE.

### INV-PUBLIC-COMPOSITION

> a theorem combining space, exactness, cost, provenance, or machine claims proves them about the same construction and execution and over the same validity domain. Conjoining true theorems about different payloads or guarded and unguarded executions is not closure.

A:401–458 binds all 16 fields to actual allocation and the recovered-memory machine certificate. The machine producer transports every field using exact memory equality. V:256–273 expands the same-object conjunction.

P01 and S01/S02 reject changes to the public proposition and memory/run identities. S03 substitutes the canonical budget; H01 narrows the exactness domain.

**Disposition:** INCOMPLETE because S03 is inconclusive and H01 unexecuted; the source composition and observed P01/S01/S02 controls are supported.

### INV-CERTIFICATE-ANTI-BYPASS

> every mandatory field advertised by a public certificate is projected by a checked typed consumer at the exact proposition and object arguments required by the acceptance contract. Deleting or weakening a field, or replacing it with a sibling fact, must break that consumer rather than leave only constructor initializers and prose unchanged.

The metadata inventory checks literal ordered parent-free 4/16/33 structures through Lean structure metadata, including names, defaults, order, absence, and parent controls. V:21–250 independently repeats all 49 expected types and projects the named producer.

All 49 P-to-True mutations have producer-pass/own-consumer-fail outcomes. F01/F02 also reject deletion. S01/S02 reject sibling identities.

**Disposition:** INCOMPLETE because S03 is inconclusive and H01/A02 unexecuted.

### INV-MUTATION-REPRODUCIBILITY

> when acceptance relies on an exhaustive, production, or public-dependency mutation campaign, the candidate contains a versioned runner or fixtures that replay every claimed case, check the exact expected failure/acceptance surface, restore tracked state, and leave the tree clean. Report prose, copied terminal output, and dangling Git objects are not replayable evidence. A public theorem additionally has a checked exact-type consumer that fails when the advertised dependency is removed; `#print axioms` over the theorem's current type is not such a consumer.

The target commits JSON v3 and an independent literal 63-case runner registry. Replay:169–211 computes declaration spans and rejects resource/off-surface diagnostics. Replay:360–425 defines actual source transformations and replacement-olean versus producer-rejection lanes. Replay:428–434 restores bytes, checks clean channels, and requires exact execution order.

P01/G01 test public/generic expected-type consumers independently of axiom output.

**Disposition:** INCOMPLETE. The machinery correctly refuses the resource failure, but the required original-target campaign does not complete 63 cases.

### INV-GLOBAL-PHYSICAL-MACHINE

> a physical-machine claim supplies one pre-execution store/word array and a checked address translation for every executed segment, including failed/dead accesses. A theorem for one suffix or component is not a whole-machine embedding.

Allocation:154–158 supplies one numeric store containing metadata and the complete repacked allocation. A:87–89 recovers that exact list before querying. PhysicalRead:19–36 translates logical spans by the metadata-prefix offset before actual loads.

PhysicalRead:145–233 covers arbitrary segments/indices under installed canonical metadata, including missing and zero-length spans. M27/M28/M30 preserve global backing, expansion, and agreement; M07/M26 constrain sentinel and attempted addresses.

**Disposition:** K/M source and named local controls supported. Empty logical sentinels need not cause physical loads. Final certification pending.

### INV-WIDTH-SCALING

> one query-independent word-width declaration bounds all stored words, addresses, sentinels, operands, and primitive results, and its capacity/width is related to input size in the form required by the public word-RAM claim. A standalone asymptotic fact about an unconstrained width function is insufficient.

Allocation:23 defines `wordWidth n = 32 + 8*packedReviewerCellWidth n`. M03 bounds it between `log2(n+2)+1` and `192*(log2(n+2)+1)`.

M04–M08, M15, and M23–M26 apply that identical width to recovered memory, sentinel, code, valid inputs, states, and operations. V’s definition pins expand fit/safety predicates.

**Disposition:** K/M source and corresponding field controls supported; final coordinator certification pending.

## All 49 literal expected propositions and observed field controls

Entries are in exact registry order. Every modified producer exited zero, and every corresponding consumer exited one with a non-resource diagnostic inside its own declaration. Each mutation replaced the quoted P with `True` and its initializer with `True.intro`.

All consumers project `packedAllocationOptimality_holds`; machine consumers project its `machine` field. Record and consumer proposition texts matched with whitespace alone ignored.

### O01-wordRoundTrip — checkO01

V:21; diagnostic V:24.

```lean
∀ width words, 0 < width →
  (∀ word ∈ words, word < 2 ^ width) →
  deserializeWords width (serializeWords width words) = words
```

### O02-wordSerializationInjective — checkO02

V:26; diagnostic V:30.

```lean
∀ width first second, 0 < width →
  (∀ word ∈ first, word < 2 ^ width) →
  (∀ word ∈ second, word < 2 ^ width) →
  serializeWords width first = serializeWords width second → first = second
```

### O03-serializedLength — checkO03

V:32; diagnostic V:34.

```lean
∀ xs : List Int,
  (allocationBits xs).length = (buildMemory xs).length * wordWidth xs.length
```

### O04-memoryRecovery — checkO04

V:36; diagnostic V:37.

```lean
∀ xs : List Int, reconstructedMemory xs = buildMemory xs
```

### O05-decoderExact — checkO05

V:39; diagnostic V:42.

```lean
∀ (xs : List Int) left right,
  allocationDecoder xs.length (allocationBits xs) left right =
    if ValidRange xs left right then some (scanWindow xs left (right - left)) else none
```

### O06-decoderLeftmost — checkO06

V:44; diagnostic V:47.

```lean
∀ (xs : List Int) left right index,
  allocationDecoder xs.length (allocationBits xs) left right = some index →
    LeftmostArgMin xs left right index
```

### O07-sameShapeMemory — checkO07

V:49; diagnostic V:51.

```lean
∀ xs ys : List Int,
  Cartesian.shape xs = Cartesian.shape ys → buildMemory xs = buildMemory ys
```

### O08-shapeInjectivity — checkO08

V:53; diagnostic V:55.

```lean
∀ n first second, first ∈ shapesOfSize n → second ∈ shapesOfSize n →
  allocationBits first.representative = allocationBits second.representative → first = second
```

### O09-uniformBudgetCount — checkO09

V:57; diagnostic V:58.

```lean
∀ n B, UniformAllocationBudget n B → shapeCount n ≤ 2 ^ (B + 1) - 1
```

### O10-uniformBudgetLower — checkO10

V:60; diagnostic V:62.

```lean
∀ n B, UniformAllocationBudget n B →
  EncodingLowerBound.doubledLogSlackLower n ≤ 2 * (B + 1)
```

### O11-canonicalCount — checkO11

V:64; diagnostic V:65.

```lean
∀ n, shapeCount n ≤ 2 ^ (2 * n + allocationRho n + 1) - 1
```

### O12-canonicalLower — checkO12

V:67; diagnostic V:69.

```lean
∀ n,
  EncodingLowerBound.doubledLogSlackLower n ≤ 2 * (2 * n + allocationRho n + 1)
```

### O13-upperCapacity — checkO13

V:71; diagnostic V:73.

```lean
∀ xs : List Int,
  (allocationBits xs).length ≤ 2 * xs.length + allocationRho xs.length
```

### O14-allocationResidualLittleO — checkO14

V:75; diagnostic V:76.

```lean
LittleOLinear allocationRho
```

### O15-runIdentity — checkO15

V:78; diagnostic V:81.

```lean
∀ (xs : List Int) left right fuel,
  run (reconstructedMemory xs) queryProgram fuel (initialState xs.length left right) =
    run (buildMemory xs) queryProgram fuel (initialState xs.length left right)
```

### O16-machine — checkO16

V:83; diagnostic V:84.

```lean
ReconstructedPackedQueryCapstone
```

### M01-allocationResidualLittleO — checkM01

V:89; diagnostic V:90.

```lean
LittleOLinear allocationRho
```

### M02-completeResidualLittleO — checkM02

V:92; diagnostic V:93.

```lean
LittleOLinear queryCompleteRho
```

### M03-widthBounds — checkM03

V:95; diagnostic V:97.

```lean
∀ n, Nat.log2 (n + 2) + 1 ≤ wordWidth n ∧
  wordWidth n ≤ 192 * (Nat.log2 (n + 2) + 1)
```

### M04-dataCapacity — checkM04

V:99; diagnostic V:101.

```lean
∀ xs : List Int, (reconstructedMemory xs).length * wordWidth xs.length ≤
  2 * xs.length + allocationRho xs.length
```

### M05-completeCapacity — checkM05

V:103; diagnostic V:107.

```lean
∀ xs : List Int,
  ((reconstructedMemory xs).length + (queryProgram.map Instruction.encoding).flatten.length +
    (queryRegisterCount + 3)) * wordWidth xs.length ≤
      2 * xs.length + queryCompleteRho xs.length
```

### M06-memoryWordsFit — checkM06

V:109; diagnostic V:110.

```lean
∀ (xs : List Int) word, word ∈ reconstructedMemory xs → word < 2 ^ wordWidth xs.length
```

### M07-allocationAddressesFit — checkM07

V:112; diagnostic V:114.

```lean
∀ (xs : List Int) address, address ≤ (reconstructedMemory xs).length →
  address < 2 ^ wordWidth xs.length
```

### M08-programFieldsFit — checkM08

V:116; diagnostic V:117.

```lean
∀ n instruction, instruction ∈ queryProgram → instruction.Fits (wordWidth n)
```

### M09-budgetExact — checkM09

V:119; diagnostic V:120.

```lean
queryBudget = 837572
```

### M10-programLength — checkM10

V:122; diagnostic V:123.

```lean
queryProgram.length = queryBudget
```

### M11-encodedProgramBound — checkM11

V:125; diagnostic V:126.

```lean
(queryProgram.map Instruction.encoding).flatten.length ≤ 5 * queryBudget
```

### M12-registerCount — checkM12

V:128; diagnostic V:129.

```lean
queryRegisterCount = 8271
```

### M13-scratchCount — checkM13

V:131; diagnostic V:132.

```lean
queryScratchWords = 8274
```

### M14-unusedRegisters — checkM14

V:134; diagnostic V:136.

```lean
∀ (xs : List Int) left right fuel r, queryRegisterCount ≤ r →
  (run (reconstructedMemory xs) queryProgram fuel (initialState xs.length left right)).final.regs r = 0
```

### M15-validInputs — checkM15

V:138; diagnostic V:141.

```lean
∀ (xs : List Int) left right, ValidRange xs left right →
  encodeInputs xs.length left right = some (initialState xs.length left right) ∧
    left < 2 ^ wordWidth xs.length ∧ right < 2 ^ wordWidth xs.length
```

### M16-natContract — checkM16

V:143; diagnostic V:146.

```lean
∀ (xs : List Int) left right,
  queryNat (reconstructedMemory xs) xs.length left right =
    if ValidRange xs left right then some (scanWindow xs left (right - left)) else none
```

### M17-leftmost — checkM17

V:148; diagnostic V:150.

```lean
∀ (xs : List Int) left right index,
  queryNat (reconstructedMemory xs) xs.length left right = some index → LeftmostArgMin xs left right index
```

### M18-result — checkM18

V:152; diagnostic V:156.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length →
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).result =
    some (optionNatPacket (SuccinctClassic.queryTraceResult xs left right).value)
```

### M19-halt — checkM19

V:158; diagnostic V:162.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length →
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).final.status =
    .halted (optionNatPacket (SuccinctClassic.queryTraceResult xs left right).value)
```

### M20-invalidGuard — checkM20

V:164; diagnostic V:168.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length → ¬ ValidRange xs left right →
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).result = some 0 ∧
    (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).reads = []
```

### M21-stepBound — checkM21

V:170; diagnostic V:172.

```lean
∀ (xs : List Int) left right,
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).steps ≤ queryBudget
```

### M22-categoryPartition — checkM22

V:174; diagnostic V:179.

```lean
∀ (xs : List Int) left right,
  let actual := run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)
  actual.steps = actual.categoryCount .memoryRead + actual.categoryCount .registerWrite +
    actual.categoryCount .arithmetic + actual.categoryCount .comparison +
    actual.categoryCount .branch + actual.categoryCount .control
```

### M23-finalStateFit — checkM23

V:181; diagnostic V:184.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length →
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).final.Fits (wordWidth xs.length)
```

### M24-transitionSafety — checkM24

V:186; diagnostic V:191.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length →
  ∀ (index : Nat) (t : Transition),
    (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).transitions[index]? = some t →
    Instruction.Safe (wordWidth xs.length) t.before t.instruction ∧ t.after.Fits (wordWidth xs.length)
```

### M25-prefixSafety — checkM25

V:193; diagnostic V:197.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length →
  ∀ fuel, fuel ≤ queryBudget →
    (run (reconstructedMemory xs) queryProgram fuel (initialState xs.length left right)).final.Fits (wordWidth xs.length)
```

### M26-readWidth — checkM26

V:199; diagnostic V:206.

```lean
∀ (xs : List Int) left right,
  left < 2 ^ wordWidth xs.length → right < 2 ^ wordWidth xs.length →
  ∀ (index : Nat) (t : Transition) (receipt : Receipt),
    (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).transitions[index]? = some t →
    t.receipt = some receipt →
    receipt.address < 2 ^ wordWidth xs.length ∧ receipt.reply = (reconstructedMemory xs)[receipt.address]? ∧
      (∀ value, receipt.reply = some value → value < 2 ^ wordWidth xs.length)
```

### M27-positionalReadBacking — checkM27

V:208; diagnostic V:216.

```lean
∀ (xs : List Int) left right index (t : Transition) (receipt : Receipt),
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).transitions[index]? = some t →
  t.receipt = some receipt →
  t.before = (run (reconstructedMemory xs) queryProgram index (initialState xs.length left right)).final ∧
    t.before.status = .running ∧ queryProgram[t.before.pc]? = some t.instruction ∧
    execute (reconstructedMemory xs) t.instruction t.before = (t.after, t.receipt) ∧
    ∃ dst addrReg, t.instruction = .load dst addrReg ∧
      receipt.address = t.before.regs addrReg ∧ receipt.reply = (reconstructedMemory xs)[receipt.address]?
```

### M28-orderedLogicalRefinement — checkM28

V:218; diagnostic V:225.

```lean
∀ (xs : List Int) left right,
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).reads =
    if ValidRange xs left right then
      (List.range 174).map (fun i => ⟨i, (metadata (SuccinctClassic.cartesianShape xs))[i]?⟩) ++
        logicalTraceReads (SuccinctClassic.cartesianShape xs) (reconstructedMemory xs)
          (SuccinctClassic.queryTraceResult xs left right).trace
    else []
```

### M29-logicalReadOnly — checkM29

V:227; diagnostic V:229.

```lean
∀ (xs : List Int) left right,
  ReadOnlyTrace (SuccinctClassic.queryTraceResult xs left right).trace
```

### M30-suppliedMemoryAgreement — checkM30

V:231; diagnostic V:236.

```lean
∀ (xs : List Int) (memory : Memory) left right,
  (∀ receipt ∈ (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).reads,
    memory[receipt.address]? = (reconstructedMemory xs)[receipt.address]?) →
  run memory queryProgram queryBudget (initialState xs.length left right) =
    run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)
```

### M31-specResult — checkM31

V:238; diagnostic V:241.

```lean
∀ (xs : List Int) left right, ValidRange xs left right →
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).result =
    some (scanWindow xs left (right - left) + 1)
```

### M32-noFailedLoads — checkM32

V:243; diagnostic V:246.

```lean
∀ (xs : List Int) left right, ValidRange xs left right →
  ∀ receipt ∈ (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).reads,
    ∃ value, receipt.reply = some value
```

### M33-invalidGuardSteps — checkM33

V:248; diagnostic V:250.

```lean
∀ (xs : List Int) left right, ¬ ValidRange xs left right →
  (run (reconstructedMemory xs) queryProgram queryBudget (initialState xs.length left right)).steps ≤ 6
```

## Remaining counterfactual predicates

The 49 field controls above use P-to-True weakenings, with immediate P → True. Their modified producers must compile; producer rejection does not count for those cases.

The remaining transformations at Replay:368–425 are:

| Case | Accepted P and mutated Q |
|---|---|
| P01 | P is the public theorem type `PackedAllocationOptimality`; Q is `True`. |
| G01 | P is the generic doubled lower theorem for `E : ExactRMQBoundedEncoding n B`; Q is `True` with the same E parameter. |
| G02 | P is the universally quantified `query_exact` field quoted above; Q is the remaining encoding structure after deleting that field. Forgetting the field weakens the interface but removes the needed proof dependency. |
| D01 | The same total exactness equation as O05 is tested after `allocationDecoder n bits left right` is replaced by `none`. |
| D02 | The same equation is tested after the decoder is replaced by `some 0` for every argument. Generic controls additionally constrain incorrect valid-window answers. |
| D03 | The same predicate `(serializeWords width words).length = words.length*width` is tested after serialization is replaced by `[]`. |
| F01 | P is O04’s exact recovered-memory equality; Q deletes its field and initializer. |
| F02 | P is M27’s full occurrence-indexed proposition; Q deletes its field and initializer. |
| S01 | P is `∀ xs, reconstructedMemory xs = buildMemory xs`; Q is `∀ xs, reconstructedMemory xs = reconstructedMemory xs`. Its checked initializer is reflexivity. |
| S02 | P is O15’s recovered/build-memory run equality for every xs/endpoints/fuel; Q replaces the right side with the identical recovered-memory run. Its checked initializer is reflexivity. |
| S03 | P retains arbitrary B; Q substitutes the canonical capacity in the count conclusion, as quoted in the finding. The checked Q initializer uses `canonicalAllocation_shapeCount_le n`, ignoring the budget. That unconditional canonical theorem also supplies P → Q. |
| H01 | P is O05’s universal exactness; Q adds `xs.length = 0` before endpoints. Its initializer applies `allocationDecoder_exact` after introducing the extra premise, directly restricting P. |
| A01 | The unchanged full typed consumer must accept. |
| A02 | The public P remains unchanged; a private Prop wrapper adds `capstone : P` and `note : True`, with a theorem constructing it. Modified producer, unchanged inventory, and full consumer must accept. |

D01–D03 and G02 are deliberately producer-rejection controls. They are not substituted for producer-pass/consumer-fail obligations.

Declaration-span checking is source-dependent. For G02 and D01–D03, the auditor reconstructed the mutated source before locating the expected producer declaration. Diagnostics merely inside the original unmutated line range would not have been sufficient.

The inherited liveness analysis also remains specific. An emitted receipt attributed to a missing operational source must satisfy M27’s fetched-load/execute/backing constraints. An empty trace would make M27 alone vacuous, but M28 requires the valid-query metadata prefix and exact logical expansion. `ReaderCorrect` constrains actual returned registers, and M31 constrains the actual halted specification answer. M30 retains failed replies in the same agreement premise. LB1 introduces no separate coverage manifest claiming every cell is live on every query.

## Source, build, trust and frozen-row evidence

The auditor checked exact HEAD, governance and contract ancestry, base/target paths and statistics, exact Git blobs, delta whitespace, clean state, frozen rows, all literal field propositions, and both registry representations.

The delta contains 49 changed files and 7504 inserted lines. The three Lean modules are additive. Predecessor machine source, README, `RMQPaper.lean`, headline identities, toolchain, and claim-policy allowances were unchanged. The scoped `FAMILY_SUMMARY` and `DIGESTION_LOG` additions accurately distinguish observed length, actual allocation, model costs, and uncharged conversions.

All 70 initial allowlisted packet files matched their manifest hashes. All 53 immutable source/neutral entries also matched exact target Git raw blobs.

All 29 complete frozen rows matched the checkpoint in order. The checker excludes only physical LF/CRLF delimiters; it does not normalize row whitespace or Unicode. Its observed controls were:

| Control | Required and observed result |
|---|---|
| Unchanged | ACCEPT / OK |
| Whitespace change | REJECT / ROW_BYTES_DIFFER |
| Missing row | REJECT / MISSING_ROW |
| Duplicate row | REJECT / DUPLICATE_ROW |
| Unicode change | REJECT / ROW_BYTES_DIFFER |
| Recognizable mojibake | REJECT / MOJIBAKE |
| Invalid UTF-8 | REJECT / INVALID_UTF8 |

The checker source hash matches the target. Its record’s CandidateHEAD was an earlier checkpoint, so content provenance was independently reconciled: checked working matrix SHA256

`89F026B5AC6467B8B32058B5F72A0105AAF39A39D74A5D725C8BDB7426B474C9`

becomes exact target raw matrix SHA256

`EE571010AD997FB25A44FFF853E2A9E30EF3528EDC564753CFCD2ED4FA9BB897`

after converting only 21 CRLF delimiters to LF. The actual checked-byte snapshot was inspected. This is provenance for the checked content, not a newly executed checker or a claim that the recorded older HEAD was the target.

Development build evidence was reconciled by source identity. Among 268 records were 252 distinct latest modules. The three new files’ recorded hashes matched raw target contents. The other 249 matched clean-checkout CRLF bytes, whose delimiter-only conversion produced the exact target Git blob IDs. Earlier failed validation/inventory records had superseded identities and were not counted as current passing checks.

The pinned version record identifies Lean 4.22.0, `x86_64-w64-windows-gnu`, commit:

`ba2cbbf09d4978f416e0ebd1fceeebc2c4138c05`.

The current run freshly compiled the generic producer, packed producer, metadata inventory, validation consumer olean, and generic consumer, in that order before backups. All five stages exited zero without timeout/output-limit flags. Replay:310–314 contains these operations.

The inventory checks the exact ordered parent-free 4/16/33 structures and its name/default/indentation/order/absence/parent controls.

The 20 explicit axiom outputs covered:

1. `boundedBitStrings_cardinality`
2. `shapeEncode_injective_on`
3. `shapeCount_le`
4. `doubledLogSlackLower_le`
5. `deserializeWords_serializeWords`
6. `serializeWords_injective`
7. `allocationBits_length`
8. `reconstructedMemory_eq_buildMemory`
9. `allocationDecoder_exact`
10. `allocationBits_shape_injective`
11. `uniformAllocation_shapeCount_le`
12. `uniformAllocation_doubledLogSlackLower_le`
13. `canonicalAllocation_shapeCount_le`
14. `canonicalAllocation_doubledLogSlackLower_le`
15. `allocationBits_capacity_le`
16. `reconstructedRun_eq`
17. `reconstructedPackedQueryCapstone_holds`
18. `packedAllocationOptimality_holds`
19. `publicContract`
20. `composedConsumer`

Their source/script identities matched the target. Serializer inverse/injection use `propext` and `Quot.sound`; the other observed outputs also include `Classical.choice`. No additional axiom was observed. This is consistent with the Mathlib-free Lean/Std plus omega policy.

Both required source scans returned no matches:

```powershell
rg -n "\b(sorry|admit|axiom|unsafe|opaque|implemented_by|partial|extern|noncomputable)\b|import Mathlib" RMQ lakefile.toml
rg -n "native_decide|Lean\.ofReduceBool" RMQ
```

Exit code one meant no match. `git diff --check` for the exact delta passed.

The auditor did not run Lean/Lake/runtime/gate commands because the frozen contract prohibited competing execution. A read-only Git batch helper stalled, was cancelled, and was replaced by bounded listing/in-memory hash reconstruction; no Git child remained.

## Exact campaign coverage

The preserved neutral packet is:

`docs/internal/extensions/lb1/evidence/replay-v3-d6dabb-inconclusive/`

Its manifest SHA256 is:

`F2AE19631427F321E1E7878F17007A75DA916C4A555AA342AC00A1C5142A7D09`.

All 129 stage JSON hashes were independently matched. `candidate.txt` names the exact target.

The first 49 exact registry IDs are individually listed above. Their 98 records satisfy modified-producer acceptance followed by rejection inside the corresponding literal consumer, without resource/import/timeout substitution.

The remaining entries, in exact registry order, are:

| ID | Expected | Observed |
|---|---|---|
| A01-BASELINE | ACCEPT | Exit zero; unchanged full consumer. |
| P01-PUBLIC-PROPOSITION | REJECT | Producer zero, consumer one; `publicContract` error V:18 inside 17–19. |
| G01-LOWER-PROPOSITION | REJECT | Producer zero, consumer one; `genericBoundConsumer` error 7 inside 5–8. |
| G02-DELETED-EXACTNESS | REJECT | Producer one; missing `query_exact` at line 142 inside mutated `sameRMQBehavior_of_encode_eq` span 134–146. |
| D01-NULL-DECODER | REJECT | Producer one; `allocationDecoder_exact` error 93 inside mutated span 90–96. |
| D02-WRONG-DECODER | REJECT | Producer one; `allocationDecoder_exact` error 93 inside mutated span 90–96. |
| D03-ZERO-SERIALIZER | REJECT | Producer one; `serializeWords_length` error 37 inside mutated span 31–38. |
| F01-DELETE-MEMORY-RECOVERY | REJECT | Producer zero, consumer one; missing field at `checkO04`, V:37. |
| F02-DELETE-READ-BACKING | REJECT | Producer zero, consumer one; missing field at `checkM27`, V:216. |
| S01-SIBLING-MEMORY | REJECT | Producer zero, consumer one; reflexive recovery cannot supply build-memory identity at V:37. |
| S02-SIBLING-RUN | REJECT | Producer zero, consumer one; reflexive recovered-run equality cannot supply build-memory-run equality at V:81. |
| S03-SIBLING-BUDGET | REJECT | INCONCLUSIVE: producer zero, consumer one, only recursion-depth exhaustion at V:57:0. |
| H01-EMPTY-ONLY-DECODER | REJECT | UNEXECUTED. |
| A02-PROOF-ONLY-WRAPPER | ACCEPT | UNEXECUTED. |

The successful ordered list is exactly the first 49 listed above followed by A01, P01, G01, G02, D01, D02, D03, F01, F02, S01, S02: **60 successful cases**. S03 was attempted but not semantically classified. H01/A02 were not attempted. There is no positive full summary.

All six runtime controls actually executed and passed in order:

`R01-EMPTY`, `R02-SINGLETON`, `R03-LEFTMOST`, `R04-ZERO-LENGTH`, `R05-ZERO-WORDS`, `R06-SAME-SHAPE`.

Startup listed six IDs; the known R04 selector then executed exactly one. Empty, whitespace, malformed-channel, and unknown runtime selectors rejected with their expected messages. Full runtime exited zero after 193.537 seconds and reported `executed=6 expected=6`. These successes do not fill missing proof/control IDs.

The outer command was:

```powershell
pwsh -NoProfile -File scripts/variable_payload_replay.ps1 -DeadlineSeconds 600
```

Session 20756 exited one with Replay:200’s resource-classification exception at `checkO09`. The terminal receipt contains its final combined output chunk, with known line-ending notices filtered. It is not a complete separately captured outer stdout/stderr transcript. Every child stage retains separate stdout/stderr.

## Restoration and remaining evidence

Replay:323–333 and Replay:428–431 restore both producer sources and both overwritten oleans, compare exact bytes with in-memory backups, and check worktree/index/untracked cleanliness. The original S03 exception propagated after those nested finally clauses; no restoration exception replaced it.

The coordinator immediately recorded empty Git status and matching generic/packed source hashes before repair work. Those hashes match raw target contents:

- Generic: `688E98C5FBCC12D17CB475FD4B381B707EC224805C9A3C1C0B1858B3270B1FFA`.
- Packed: `FB78AD4A5C23709E0EAB724D02F5DEB46E23A535D5AC63CC6E2B4DE54192972D`.

The audit checkout uses CRLF working bytes; converting only its 329/461 CRLF delimiters recovers those exact raw-content hashes.

Baseline olean hashes were not persisted. This report therefore records the runner’s executed byte-comparison/finally evidence and the coordinator’s immediate source/clean-state observation, **not** an independently compared before/after olean-hash pair. It does not claim a positive final summary exists.

The audit checkout itself remained clean at:

`d6dabbec10648f368df9ddcd32102f84deffb281`.

Historical Windows deadline evidence actually created descendant PID 29284 and included it in the terminated set. The 30-second timeout completed in 30.284 seconds with `TimedOut = true`. The earlier probe that did not establish the descendant condition remains inconclusive. Windows job observations do not certify POSIX behavior.

Current exact-target outcomes for all five focused entry points remain unprovided. The full runner’s internal runtime/diagnostic work and historical focused records were inspected, but no focused invocation is inferred from another mode. CLI/environment conflict rejection remains source-inspected only.

The repaired source is a new target. Its future passing results cannot retroactively certify this original commit. Coordinator build/aggregate evidence and report-containing-tree strict claim, design, and whitespace checks remain pending.

## Rejected objections

The following objections were independently considered and rejected from source evidence:

- The bounded universe might contain only exact-length-B strings. It contains every length zero through B, with the correct cardinality.
- Shape injection might be assumed. The four-field generic interface instead derives it from exact valid-window answers.
- The canonical decoder might retain xs or shape advice. Its executable body depends only on n, bits, and endpoints, while universal size-n exactness prevents a fixed hidden input from supplying all answers.
- Variable allocation length might be erased by zero padding. Positive-width serialization retains observed length and has a left inverse on arbitrary finite bounded lists.
- Same-shape sharing might contradict injection. The injection is over Cartesian shapes, not all value lists.
- The lower bound might concern one input or a canonical budget substituted for arbitrary B. Its literal source quantifies a budget over every size-n input; the S03 verification gap is separately reported.
- Machine claims might concern a sibling store or omit raw guards. Exact memory/run identities and the literal field types preserve the intended objects and guard domains.
- Trace evidence might constrain only logs. Primitive state updates, reader output-register theorems, M27/M30, and M31 constrain actual execution and returned values.
- Width scaling might be detached from storage and operations. The same n-linked width appears throughout memory, sentinel, code, input, state, and transition fields.
- Inventory or axiom output might establish public dependency by itself. They do not; separate literal consumers and mutation controls are required.
- Startup/list might count as query execution. It does not; actual runtime case outputs are separately recorded.
- An unchanged `Open` acceptance cell might itself be a proof defect. Frozen text and actual proposition/evidence closure determine the disposition.
- Superseded development failures might be current failures. Their identities differ. Conversely, historical passing focused records are not automatically current-target observations.

No new query algorithm, compiler/backend, preprocessing-time proof, cell-probe result, alias migration, or cost-tightness theorem was assigned here. These boundaries do not waive any frozen semantic, runtime, trust, or reproducibility requirement.

## Roadmap alignment and proof digestion

The source follows the extension’s assigned endpoint: an observed-length encoding of every actual PQ1 cell, exact recovery of that word array, and lower/upper/machine claims about the same construction. Its literal consumers and attacks address the intended public dependency discipline. Required execution closure is nevertheless incomplete.

Conceptually, the change turns the actual word allocation into the object of the information lower bound. In plain English, the lower and upper space statements now describe the same stored information, and the machine theorem runs on its recovered words.

Live assumptions include observed bit length, external n and n-only fixed advice, a budget uniform over all size-n inputs, positive n-linked width, bounded numeric words, half-open leftmost semantics, representable endpoints for raw execution, and the declared scalar primitive model. Code and scratch are separately counted. Mathematical bit conversion, preprocessing, and outer conversion have no new charged-time theorem. The trust base remains Lean/Std plus omega with the observed standard Lean axioms.

A skeptical graduate student should next ask where the representation boundary becomes charged executable work: what input format, temporary storage, and conversion time are needed before the recovered word array is available to the fixed query program? That is a subsequent model-refinement question, not a reason to waive the present replay failure.

The immediate next target is narrower: repair the S03 consumer behavior without weakening its proposition or mutation, complete all 63 cases and required focused modes on the repaired exact target, obtain a fresh independent audit, then obtain coordinator certification of the report-containing durable tree.

This report text is complete for the original target and returns **INCOMPLETE**. It has not been written or certified as a durable report artifact by the auditor.