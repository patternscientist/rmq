param([string]$BoundaryCase, [string]$EvidenceRoot)
$ErrorActionPreference = 'Stop'
$ErrorView = 'NormalView'
$target = 'C:\Users\poin\.codex\worktrees\2fb8\RMQ\scripts\preprocessing_contract_replay.ps1'
switch ($BoundaryCase) {
  'omitted' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot }
  'valid' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase 'C01_REFLECTION' }
  'empty' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase '' }
  'whitespace' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase ' ' }
  'malformed' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase 'C01_REFLECTION,C02_CAP' }
  'unknown' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase 'C99_UNKNOWN' }
  'zero' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase '0' }
  'missing' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase }
  'duplicate' { & $target -SelectorProbeOnly -EvidenceDirectory $EvidenceRoot -OnlyCase 'C01_REFLECTION' -OnlyCase 'C02_CAP' }
  default { throw 'unknown boundary fixture' }
}
exit $LASTEXITCODE