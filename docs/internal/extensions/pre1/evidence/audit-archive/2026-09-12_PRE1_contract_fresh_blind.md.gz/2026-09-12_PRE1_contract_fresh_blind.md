Status: INCOMPLETE
Phase: CONTRACT_AUDIT
Contract verdict: CONTRACT_AUDIT_PASS_WITH_REQUIRED_AMENDMENTS

# PRE-1 contract phase: fresh blind exact-commit audit (PRE-1-A1)

Status INCOMPLETE is the only form available to this contract-phase audit: the
six builder rows are OPEN by design, no builder exists at the target, and the
implementation-completion form is deliberately not used. The verdict below is
about the contract phase only; builder authorization and acceptance remain the
coordinator's.

## 1. Identity and scope

| Item | Value |
| --- | --- |
| Audit mode | FRESH BLIND DELTA, report-only auditor PRE-1-A1 (Claude worker), no inherited author or coordinator conversation |
| Commissioning prompt | `extension-coordination-20260911/claude-coordinator-20260912/PRE1_A1_CONTRACT_FRESH_BLIND.md`, 35,904 bytes, SHA-256 BD68429B5298D450A96482A563F7F223BCB7F74CBB0D9E43BFFCB8AB392915DF (verified) |
| Target commit | `c1c970b8bfbae03163633365e512d487ae1c98f2` (verified as initial detached HEAD; `git status --porcelain` empty before any read) |
| Contract/source commit | `26d6b5c2b10ed06ae4f72d9075d746ede987bdab` |
| Delta base / governance ref | `0e6a00f654abc64f8b68988fa9675b9a839dca2f` (merge-base of base and target is the base itself) |
| Candidate branch (not followed) | `codex/pre-1-packed-preprocessing` |
| Audit worktree | `C:/Users/poin/Documents/RMQ/.claude/worktrees/pre1-a1-contract-audit`, detached, `core.autocrlf=true`, no `.lake` at start |
| Toolchain | `lean-toolchain` = `leanprover/lean4:v4.22.0`; binaries `C:/Users/poin/.elan/toolchains/leanprover--lean4---v4.22.0/bin/{lean,lake}.exe` (Lake 5.0.0-src+ba2cbbf; `lake build -j` is rejected: "unknown short option '-j'") |
| Host | Windows 11 Pro 10.0.26200, PowerShell 7.6.6 (`pwsh`), Windows PowerShell 5.1 available, Git, python; shared with a coordinator gate and other Lean workers; `LEAN_NUM_THREADS=1` on every Lean/Lake invocation; one heavy Lean process at a time in this tree |
| Preflight | `scripts/project_skill_preflight.ps1 -GovernanceRef 0e6a00f... -AllowNoRequiredSkills -RuntimeProjectSkills "rmq-audit-prompt,rmq-coordinator,rmq-proof-sprint"`: PASS, exit 0, 3.807 s, `required_mode=explicit-no-role`, checkout = target |
| Write scope used | this file only (uncommitted), plus untracked scratch under the worktree `.lake/` (disposable clone `.lake/pre1-replay-copy`, build outputs) and the session scratchpad |
| Not touched | the author worktree `C:/Users/poin/.codex/worktrees/2fb8/RMQ`, `scripts/gate.ps1`, any full default `lake build`, any branch/reset/clean/push |

Delta verification. `git diff --name-status 26d6b5c..c1c970b` touches exactly nine
paths, all under `docs/internal/`: `WORKFLOW_DESIGN_DECISIONS.md` (M),
`extensions/pre1/ACCEPTANCE_MATRIX.md` (M, +22 lines), `extensions/pre1/REPORT.md`
(M), and six new files under `extensions/pre1/evidence/` (`aggregate-gate.zip`,
`aggregate-summary.json`, `archive-integrity.json`, `final-evidence-summary.json`,
`gate-failure-diagnostics.zip`, `postgate-final-checks.zip`). No Lean, script,
registry or manifest byte differs between the contract commit and the target.
(The prompt's phrase "only evidence/docs under docs/internal/extensions/pre1" is
slightly narrower than the actual delta, which also appends to
`docs/internal/WORKFLOW_DESIGN_DECISIONS.md`; still docs-only.)
`git diff 0e6a00f..c1c970b -- lakefile.toml lake-manifest.json lean-toolchain RMQ/Core/WordRAM/Packed RMQPaper RMQ.lean`
is empty: shared Packed source, the public roots and the Lean/Std-only footprint
are unchanged. Nothing outside `RMQ/Core/WordRAM/Construction/` imports the new
modules; `RMQ.lean` is unchanged, so the default `lake build` target does not
reach them (see finding P2-1).

Independence log. Before forming conclusions I read only: the prompt; AGENTS.md;
docs/internal/AUDIT_PROTOCOL.md; the six Construction modules; the consumer,
firewall and replay scripts; `contract_cases.json`; `primitive_manifest.json`;
CONTRACT.md, AMENDMENTS.md, ATTACK_TABLE.md, SOURCE_FACTS.md, REPLAY_DESIGN.md,
ACCEPTANCE_MATRIX.md (at 26d6b5c, at the target and in the worktree); the
historical plan lines 220-330 and `wf3_attack.json`; baseline producers
`Packed/Primitive.lean`, `Packed/Allocation.lean` (buildMemory/metadata),
`Packed/Capstone.lean` (the query capstone record), `Packed/QueryStatic.lean`
anchors; `scripts/gate.ps1` roster and `.github/workflows`; and the raw evidence
indexes (`REPLAY_INDEX.json`, `replay-full-summary.json`, `archive-integrity.json`,
`aggregate-summary.json`, `final-evidence-summary.json`) and the extracted
`replay-full.zip` stage receipts (for durations and stage outputs). Two read-only
subagent leaves (amendment comparison, 15-case catalogue) received the same
restrictions and returned after my own source conclusions were formed; their
tables agree with mine and are folded into sections 7 and 8 with my own
verification noted. Section 13 labels the stage at which
`docs/internal/extensions/pre1/REPORT.md` and the single permitted coordinator
file (`extension-coordination-20260911/pre1-review/aggregate-retry/result.json`)
were consulted, after all independent conclusions and after the probe compiled.

## 2. Verdict and required amendments

**CONTRACT_AUDIT_PASS_WITH_REQUIRED_AMENDMENTS.**

No load-bearing control is false, no required control is missing that a narrow
amendment cannot add, and the replay and consumer evidence reproduces exactly in
a clean detached copy of the target (section 11). Every proposition the
contract phase advertises as checked is a real theorem at the stated type with
standard axioms only. The contract's anti-oracle intent survives the amendments.
But four routes by which a later builder could close a frozen row against the
contract's letter while defeating its spirit are excluded today by prose only,
and one of them (the input length obtained without the header load) is
demonstrated by a compiled probe. The coordinator must impose the following
amendments, in this order, before authorizing builder construction:

| # | Amendment (exact change) | Frozen row protected | Exact location to change |
| --- | --- | --- | --- |
| A1 | Add a run-level header clause tied to the actual run, as a checked obligation of the accepted program, not of `headerInstruction` alone. Two conjuncts, both quantified over every `width xs` including `xs = []`: (a) the accepted run from `{ wordInputState width xs with memory := put (encodeInput width xs) 0 none }` and from `{ comparisonInputState xs with memory := put (comparisonInputState xs).memory 0 none }` ends in `status = .fault`; (b) in the accepted run from the intact initial states, no `reserve` transition precedes the first `load` transition whose address register holds 0 (before that load the machine has no other source of `n`: registers start at zero, loads of key cells return keys only, and out-of-range loads fault). State both as fields of the future run/builder certificate, project them in the typed consumer, and add a replay case that deletes or weakens each field. Reword CONTRACT.md:64-66 and AMENDMENTS.md:39 from "the length is obtained by the actual headerInstruction" to "the accepted run must obtain the length through the actual header load; this is a checked field (name it), because `reserve` exposes `extent = n + 1` in the word model". | REQ-PRE-INPUT ("length read from a pinned header cell"), CHK-PRE-CONTROLS ("missing input header"), O-POINTWISE/R1 header clause | `docs/internal/extensions/pre1/CONTRACT.md` lines 64-66 (C1); `AMENDMENTS.md` line 39; `RMQ/Core/WordRAM/Construction/Contract.lean` (`ProgramContract` or a new run certificate schema); `contract_cases.json` (new case); `scripts/preprocessing_contract_check.lean` (projection) |
| A2 | Bind the executed program to one parameterless declaration and make the literal pins checkable: require that `efficientBuild`'s run relation and the accepted `ProgramContract` instance both name the same `def builderProgram : Program` with no width, size or input parameter; that the accepted `family` is definitionally `fun _ => builderProgram`; and that the builder replay registry contains (i) a case that parametrizes `builderProgram` by width or size and (ii) a case that changes each literal numeral, each failing at a pinned consumer line. Correct the overstatement at CONTRACT.md:30-31 ("fixes ... to source-level literal numerals"): `ProgramContract` fixes them to `Nat` parameters; only the future consumer can pin numerals. | REQ-PRE-MACHINE ("uniform finite construction program independent of xs"), INV-PROGRAM-ACCOUNTING, INV-WIDTH-SCALING | `CONTRACT.md` lines 27-35 (C1) and 192-193; `Contract.lean` docstring of `ProgramContract` (lines 14-16); `REPLAY_DESIGN.md` (builder-phase cases) |
| A3 | Pin the left-hand side of `efficientBuild_eq_buildMemory` syntactically (a BR-F1 analogue): `efficientBuild xs` must be defined inside the firewalled import closure as a positional projection of the accepted run's final memory (a contiguous address range whose base and length come from run state, e.g. registers or the halt value), never as a function that names `buildMemory`, `cartesianShape`, `metadata` or any semantic builder, and never through an intermediate adapter store. Add the future `Program`/`Run`/`Emit` module(s) to the firewall allowlist and manifest as part of this amendment. | REQ-PRE-EXACT, REQ-PRE-JOIN, INV-STORE-IDENTITY, INV-VALUE-DEPENDENCY | `CONTRACT.md` "Required construction after contract acceptance" (lines 183-201) and C3 (lines 139-140); `scripts/preprocessing_contract_firewall.ps1` `$allowedImports` (lines 9-15) and `primitive_manifest.json` (planned entries) |
| A4 | Restore the historical "CI-enforced" property of O-FIREWALL: add `scripts/preprocessing_contract_firewall.ps1` and the PRE contract producer/consumer check (`lake build RMQ.Core.WordRAM.Construction.Contract` followed by `lake env lean scripts/preprocessing_contract_check.lean`, or the replay's `-StartupOnly`) to the `scripts/gate.ps1` roster (`$expectedCheckers`, with an `Invoke-Checker` call), so that a later widening of `Prim`/`execPrim` or of the import closure fails the aggregate gate and CI rather than only a replay the author runs. Update CONTRACT.md:142-149 and AMENDMENTS.md:51 accordingly. | REQ-PRE-CONTRACT ("required gate evidence"), O-FIREWALL ("CI-enforced"), R13 (ISA must not be widened silently after audit), INV-VALIDATION-REACH | `scripts/gate.ps1` roster and call sites; `CONTRACT.md` lines 142-149 and 203-211; `AMENDMENTS.md` lines 51-53 |

Recommended (not required before builder authorization): R1 name the shape of
the future per-transition safety predicate (a `Prim.Safe width s p` / `State.Fits width`
analogue covering registers, memory values, `extent`, `pc`, shift amounts `< width`,
non-underflow, nonzero divisors), because three catalogue rows (FK-3, FK-12,
FK-14) and INV-INSTRUCTION-ATOMICITY on the unbounded-`Nat` arithmetic all rest
on that one future row (section 6, CONTROL-PQ). R2 make the replay verdict
matcher require that the set of failing consumer lines equals the expected set
rather than `Contains` (section 6, REPLAY-18). R3 state in CONTRACT.md C3 that
`Program`, `Uniform`, `programWords`, `CodeAccounting` stay in Controls.lean and
are consumed only from outside the closure (Contract/Capstone), so the
firewalled run module never needs a sibling copy (section 6, FIREWALL-PLACEMENT).
R4 ATTACK_TABLE.md wording: FK-5's cheap variant (fixed shape-independent tables)
is reclassified as counted code, not forbidden; FK-1's rejecting basis is run
identity (REQ-PRE-EXACT/MACHINE), not O-REPLAY, whose own text disclaims a kill.

## 3. Findings

No P0 finding: no `sorry`/`admit`/`axiom`/`unsafe`/`opaque`/`implemented_by`/`partial`/`extern`/`noncomputable`/`import Mathlib` anywhere in `RMQ/` or `lakefile.toml` (rg exit 1), no `native_decide`/`Lean.ofReduceBool` in `RMQ/` (rg exit 1); the nine `#print axioms` print only `propext`, `Classical.choice`, `Quot.sound`; every advertised control is a real theorem at its stated type; the delta touches no shared source.

### P1-1 The contract does not force the input length through the header load (HEADER-AND-LENGTH-LEAK)

Scenario. `Prim.reserve dst` writes `s.extent` into register `dst`
(`Construction/Primitive.lean:147`), and `wordInputState width xs` has
`extent := inputCellCount xs = xs.length + 1` (`Model.lean:42`, `Input.lean:36`).
The three-instruction program `[reserve 2, constant 3 1, arithmetic sub 1 2 3]`
therefore places `xs.length` in register 1 without any `load`.

Evidence (compiled probe, scratchpad `HeaderLeakProbe.lean`, SHA-256
08690A81704EC8073E96241C6F76A53AF40867CE0B66668896F57C44CF4CA29C, 3,458 bytes,
`lake env lean` exit 0 in 2.272 s against the built target modules, every
theorem `depends on axioms: [propext]`):
`lengthLeak_recovers_length : ∀ width xs, (interpretPrims lengthLeakPrims (wordInputState width xs)).regs 1 = xs.length`;
`lengthLeak_ignores_missing_header : ∀ width xs, ... regs 1 = xs.length ∧ ... status = .running` on `{ wordInputState width xs with memory := put (encodeInput width xs) 0 none }`;
`lengthLeak_no_load : ∀ p ∈ lengthLeakPrims, ∀ dst address, p ≠ .load dst address`;
`lengthLeak_contract : ProgramContract lengthLeakProgram (fun _ => lengthLeakProgram) 3 10` (literal pins, `closed_uniform`, all four fields by `rfl`);
`lengthLeak_comparison_model : ∀ xs, (interpretPrims lengthLeakPrims (comparisonInputState xs)).regs 1 = 0`.

What the contract actually checks: `header_read`/`missing_header_fault`
(`Model.lean:74-78, 86-90`), `comparison_header_read`/`comparison_missing_header_fault`
(`:80-84, 92-96`), `ContractPrerequisites.headerRead` (`Contract.lean:30-35`) and the
consumers at `preprocessing_contract_check.lean:16-21, 61-67` are facts about the
single instruction `headerInstruction = ⟨.load 1 0⟩` on the initial states. They
constrain no program. CONTRACT.md:64-66 ("the length is obtained by the actual
headerInstruction = load 1 0. Missing cell 0 faults, including for n=0. The
header is not supplied independently in a register") and AMENDMENTS.md:39 are
prose. No `ProgramContract` field, `ContractPrerequisites` field, consumer line
or production guard rejects the probe.

Implication. A builder could satisfy REQ-PRE-INPUT's "length read from a pinned
header cell" and CHK-PRE-CONTROLS' "missing input header" control with a
program that never reads cell 0: its missing-header control would have to be
stated as "still succeeds" or not stated on the run at all, and the
word-model corollary's input model would silently become "length supplied by
the allocator". The leak is specific to the finite-key word model
(`comparisonInputState.extent = 1`, `Model.lean:55`, so the same trick yields 0
there); a program correct in both stated models must read the header, but
nothing checks that. Amendment A1 is required; it is narrow (one checked field on
the run plus one replay case).

### P1-2 `ProgramContract` excludes size- and width-indexed programs by prose only (AMENDMENT-INTENT, INV-PROGRAM-ACCOUNTING)

Scenario. `ProgramContract program family k b` (`Contract.lean:17-22`) has fields
`uniform : Uniform program family`, `lengthPinned : program.length = k`,
`encodedPinned : programWords program = b`, `codeBits : ∀ width, CodeAccounting program width (b * width)`.
`family` is a free parameter unconnected to any run; `closed_uniform`
(`Controls.lean:77-79`) discharges `uniform` for any `program` with
`family := fun _ => program`. `k` and `b` are `Nat` parameters, so
`ProgramContract P (fun _ => P) P.length (programWords P)` is provable by `rfl`
for any closed `P`. Consequently a width-indexed family
`B : Nat → Program` can be certified per member as
`ProgramContract (B w) (fun _ => B w) k b`, and if `B w` has uniform shape (for
example one `constant 0 ⟨w % 2^32, _⟩` per member) the pins `k = 1`, `b = 3` are
even literal numerals independent of `w`. Since PQ1's width is a function of
`n` (`wordWidth n = 32 + 8 * packedReviewerCellWidth n`, `Packed/Allocation.lean:23`),
width-indexing is size-indexing: FK-5 re-enters through the width parameter and
the per-width baked microtables become "code".

What excludes it today: only CONTRACT.md:27-35 ("one closed finite Program
constant", "unparameterized program declaration") and REQ-PRE-MACHINE's text.
CONTRACT.md:30-31 overstates the checked object ("`ProgramContract` additionally
fixes instruction count and full encoded-word count to source-level literal
numerals"). The matrix appendix row "C1 / O-UNIF" (ACCEPTANCE_MATRIX.md:339)
says "Every xs uses one program object", which is true only if `family` is the
run's actual program selector; nothing ties them.

Implication. The intent of R1's closed-constant branch survives, but as a
builder-phase consumer obligation that the contract does not yet spell out in a
form a replay can test. Amendment A2 is required (prose plus two builder-phase
replay cases); no source repair is needed now.

### P1-3 No syntactic pin on the emitted allocation; a sibling extraction is not excluded (INV-STORE-IDENTITY, REQ-PRE-EXACT)

Scenario. The contract pins the right-hand side (`PackedWordRAM.buildMemory xs`,
CONTRACT.md:10-11, AMENDMENTS.md:75) and both initial states
(`wordInputState`, `comparisonInputState`), but "emitted cells" (CONTRACT.md:192)
is never defined: nothing says how `efficientBuild xs : List Nat` is read out of
the run's final `Memory := Nat → Option Nat`. A builder outside the firewall
could define `efficientBuild xs := (List.range (buildMemory xs).length).map (fun i => (final.memory (base + i)).getD 0)`
or route the extraction through a semantic adapter, and then run the PQ1 query
on that list. The historical contract B had BR-F1/BR-F2 for exactly this
(`wf3_attack.json`, FK-6 B row); the amended contract has no analogue.
CONTRACT.md:139-140 requires future Program/Run files to be inside the
firewall, which would make `buildMemory` unnameable in the extraction if the
extraction lives there, but the text does not say the extraction must live there.

Implication. REQ-PRE-EXACT could be closed against a list that is not the
positional content of the cells the builder wrote, and REQ-PRE-JOIN's query
would then run on a sibling. Amendment A3 (LHS pin inside the closure, positional
extraction from run state) is required; it is a contract sentence plus a planned
allowlist extension, not a source change now.

### P2-1 The firewall, the contract build and the typed consumer are reached by no gate or CI (INV-VALIDATION-REACH, O-FIREWALL intent)

Evidence. `scripts/gate.ps1` roster (`$expectedCheckers`, line 656 ff.) and all
`Invoke-Checker` call sites contain no reference to `preprocessing_contract_*`
(rg over `scripts/gate.ps1` and `.github/`: no matches). `.github/workflows/ci.yml`
runs `./scripts/gate.ps1` and `./scripts/claim_drift_scan.ps1 -Strict`; the
default `lake build` target `RMQ` (`lakefile.toml`, `RMQ.lean` unchanged) does not
import `RMQ.Core.WordRAM.Construction.*`. The only invocation of the firewall is
`scripts/preprocessing_contract_replay.ps1:157-163`. CONTRACT.md:206-208 admits
"the existing default root does not import these new declarations". The
coordinator's aggregate PASS (18 of 18 checkers, 9,678.093 s, on this exact
commit) is therefore silent about the Construction modules: it would have
passed identically had they failed to compile.

Implication. The historical O-FIREWALL row said "Import firewall, CI-enforced";
AMENDMENTS.md:51 replaces it with "production guards" that no gate runs. R13's
protection (no silent ISA widening between contract audit and builder audit) is
currently supplied only by the author-run replay and by the next fresh audit.
Amendment A4.

### P2-2 Unbounded-`Nat` arithmetic is atomic only under a future width row; the contract names the row but not its shape (INV-INSTRUCTION-ATOMICITY, INV-WORD-WIDTH, INV-WIDTH-SCALING)

Evidence. `Arithmetic.eval` (`Construction/Primitive.lean:26-36`) is textually the
accepted PQ1 evaluator (`Packed/Primitive.lean:32-42`; `Conservative.arithmetic_eval`
proves equality by `cases ... rfl`) over unbounded `Nat`; registers, memory
values, `extent` and `load` results are unbounded `Nat` (`:16-17, :112`). One
`shl` by an operand near `2^32` produces a register of about `2^32` bits in one
charged tick; repeated `mul` doubles bit-length per tick. PQ1 closes this with
`Instruction.Safe` (`Packed/Primitive.lean:205-213`) and `State.Fits` (`:199-201`)
proved on every reachable transition; the Construction model has no analogue at
the target. CONTRACT.md:94-96 ("later safety proves no overflow, underflow, zero
division or oversized shift on accepted runs") and REQ-PRE-COST ("Prove all
word/address/value bounds") name the obligation.

Implication. Correctly deferred and explicitly OPEN, so not a contract defect;
but FK-3 (big-register cheat), FK-12 and FK-14 (registers as scratch) all rest on
that single future row, and INV-INSTRUCTION-ATOMICITY's per-arm inspection is
only meaningful under it. Recommended R1 (name the predicate shape, including
`extent`, stored values, `pc`, shift amounts `< width`).

### P2-3 Author replay evidence was produced on a dirty pre-commit tree; exact-commit reproduction is supplied by this audit, not by the committed archive

Evidence. `replay-full.zip` `report.json`: `baselineHead = 0e6a00f...`, baseline
`git status` had 42 lines (four modified docs and 38 untracked new files),
`deadline=120`, `admin=60`, PowerShell 7.6.5. The runner recorded and restored
that dirty state exactly (by design, REPLAY_DESIGN.md:37-39). The eleven
`sourceHashes` in `replay-full-summary.json` equal the CRLF-to-LF normalized
hashes of the committed files at the target (section 12), so the replayed bytes
are the committed bytes; but the archive itself is not evidence on
`c1c970b`. The full 18-case run in this audit's clean detached copy at the
exact target (section 11) is the exact-commit evidence.

### P3-1 Replay verdict matcher accepts extra failing lines

`Test-CaseVerdict` (`preprocessing_contract_replay.ps1:258`) checks
`Output.Contains(expectedSurface)`. The author's `C16_CODE_COUNT-consumer`
output contains errors at `:42:86`, `:43:0` and `:44:94` and passes on `:44:`.
The registered mutations are exact, so no false pass exists today, but a future
shotgun mutation that breaks every consumer line would satisfy every case's
surface. Recommended R2.

### P3-2 `Program`, `Uniform`, `programWords`, `CodeAccounting` are defined in the oracle-hosting module

`Controls.lean` imports `RMQ.Core.Shape` (`:2`) and defines the forbidden
`oracleBPWord`/`oracleSemantics` (`:31-35`) alongside the four accepted-program
predicates (`:71-98`). A firewalled run module cannot import Controls; it does
not need to (`Program` is an abbreviation for `List BInstr`; the predicates are
consumed from outside the closure by Contract.lean, which already imports both
Controls and Conservative). CONTRACT.md should say so to prevent a sibling
`Uniform` inside the closure. Recommended R3.

### P3-3 Documentation nits

`REPLAY_DESIGN.md:48` and the observed Lake behavior agree ("does not support -j"),
but the commissioning runtime facts say `lake build -j1`; the pinned Lake
rejects `-j`, and the replay correctly omits it. ATTACK_TABLE.md rows FK-1 and
FK-5 name the wrong basis or omit the reclassification (Recommended R4).
`Primitive-check.json` and `initial-build.json` in `evidence/` are retained
development failures (a stale `Primitive.lean:188` syntax error; an elan proxy
download attempt), labelled as such in REPORT.md; they are not final passes and
must not be counted as evidence of anything but iteration.

## 4. Dispositions of the 31 frozen acceptance IDs

Frozen byte integrity (development-loop check). The 31 table-row content byte
strings (ten rows of the requirement-to-evidence table, 21 single-row invariant
tables) and the 31 `###` verbatim sections were extracted from the blob at
`26d6b5c` (37,510 bytes, LF, SHA-256 A427DC208177E745DC1905D8F1B56BB0AF02F2CE1DCFDBE289EACB84CF9DD337),
the blob at the target (38,845 bytes, LF, DB69212F1F75F9F9DB30E0A86BE8B43B4292CCED054877BAAD96F5917A1E4569)
and the worktree file (39,240 bytes, CRLF, A3499A04FBE3C5AA2C49265A8B26B8E1CC1A0704A0BE2DADB21E30EA0F087AF4;
LF-normalized equals the target blob). Every ID occurs exactly once as a row and
once as a section in each tree, in the frozen order; all 31 row strings and all
31 section bodies are byte-identical across the three trees (delimiters split,
no content normalized). The target is the contract blob plus a pure 1,335-byte,
22-line appendix ("Aggregate disposition and diagnostic hold").

Legend. CHECKED = checked now on contract-phase artifacts (tier 1/2/3 evidence
named). ADEQUACY = "Full extension" row that the frozen matrix leaves OPEN; the
disposition is whether the amended contract forces non-vacuous closure.
A-n = depends on amendment n above.

| ID | Phase | Disposition |
| --- | --- | --- |
| REQ-PRE-CONTRACT | checkable now | CHECKED with amendments. Contract and ledger exist and reconcile C1-C4 with PQ1 (sections 7-8); O-UNIF/O-WORKCAP/O-FIREWALL/O-CONTROL/O-POINTWISE header clause are frozen in CONTRACT.md and carried by checked fields (`ContractPrerequisites.headerRead/reflection/workCap/constantCap/oracleControl/uniformControl`); 15/15 catalogue dispositions exist and are re-derived independently (section 7); typed consumers, negative controls, gate evidence exist. Residual: the frozen sentence "preserving the anti-oracle intent" is met for all sizes only with A1-A3 (prose-only exclusions); "required gate evidence" is met for the replay but the aggregate gate does not reach the modules (A4). Not satisfied by document existence: every clause was traced to a theorem, guard or named future row. |
| REQ-PRE-INPUT | ADEQUACY | Adequate with A1. Checked now: unsigned header `encodeInput width xs 0 = some xs.length` (`Input.lean:80-82`); pointwise cells (`:85-87`); order refinement `encodeInt_lt_iff/le_iff/eq_iff` under `SignedFits` on both operands (`:59-78`); representability `encodeInt_lt_capacity` (`:51-56`), `encodeInput_word_fits`/`address_fits` under `InputFits` (`:103-128`); all-size witnesses `zero_inputFits` (`:159-165`) and `inputFits_all_sizes` (`:169-173`, labelled witness only); comparison model `comparisonInputState` with `loadKey`/`compareKey` as separate charged categories (`Primitive.lean:59-60, 102-103, 148-153`); no sorting/rank function exists in the closure. Gap: "length read from a pinned header cell" is not forced (P1-1). Finite-key premise is named (CONTRACT.md:59-62, 74-77). |
| REQ-PRE-MACHINE | ADEQUACY | Adequate with A2 and A4. Uniform finite program: `Uniform` (`Controls.lean:74-75`) plus `ProgramContract`; conservative mutable extension: `Conservative.execute_eq_of_fits` (result component, running prestate, `Fits 32`); every primitive is one charged category (`Prim.category` exhaustive, `:90-103`); interpreter isolated from RMQ imports and host lists (firewall + arm inspection, section 6); work must be derived from `checkedStep`/`interpretPrims` (CONTRACT.md:107-117). Routes left open by checked objects: width/size-indexed family (P1-2, A2); the macro route is closed structurally (13 scalar arms) but the big-register route needs the future safety row (P2-2). |
| REQ-PRE-EXACT | ADEQUACY | Adequate with A3. RHS pinned to `buildMemory xs` including 174 metadata words (`Allocation.lean:47, 142-152, 157-158`); no fittable padding parameter (exact list equality). Gap: LHS extraction not pinned (P1-3). Pure semantic builders as specification only: stated (CONTRACT.md:189-190, REQ text); enforceable via the firewall only if the extraction is inside the closure (A3). |
| REQ-PRE-COST | ADEQUACY | Adequate; construction open. Literal constants C, D, Cw, Dw are required by text (CONTRACT.md:193-194); the model supports peak-extent accounting (`extent` grows by exactly one per `reserve`, `CleanTail` preserved by `reserve`/`store`, `Model.lean:12-29`); registers are unbounded storage outside `extent` and must be bounded by the future safety row (P2-2). Fuel is not the cost theorem (FK-15). No route to vacuous closure found beyond the width row. |
| REQ-PRE-JOIN | ADEQUACY | Adequate with A3. The consumer `fullyChargedPackedQueryCapstone_holds` exists (`Packed/Capstone.lean:173-174`), a 33-field `Prop` record every run-dependent field of which is stated over `buildMemory xs`, so exact `efficientBuild xs = buildMemory xs` transports it by rewriting (FK-13 closed for existence). Width join: `constants_fit_width` needs `32 ≤ width` and `wordWidth n ≥ 32` by definition. Arbitrary-Int and finite-key corollaries are required separately (CONTRACT.md:198-200). Sibling-store route closed only by A3. |
| CHK-PRE-CONTROLS | ADEQUACY | Adequate with A1. Named controls are listed (REQ text; matrix row "RMQ.Validation.Preprocessing -> actual builder/evaluator"). The "missing input header" control is meaningful only if the run must read the header (A1). "The production builder, not a copied model" is enforceable by the firewall/manifest only if the builder lives inside the closure (A3/A4). |
| REPLAY-EXACT-REGISTRY | checkable now | CHECKED. Registry version 1, exactly 18 cases, independent ordered ID list (`replay.ps1:29-35`), frozen content SHA-256 `aaec37a6...` recomputed by me from the worktree bytes after CRLF-to-LF (match); `Assert-Registry` rejects empty/missing/extra/duplicate/reordered/version/hash (`:65-115`), self-tested (7 cases, executed by me: PASS); executed IDs compared to selected expected IDs (`:561-564`); my full run reports executed = expected = 18 (section 11). |
| REPLAY-SELECTOR-NONVACUITY | checkable now | CHECKED. Omitted selects all 18; one valid ID selects one; bound empty/whitespace/malformed/unknown/zero/missing/duplicate reject before semantic execution with pinned surfaces (`:117-124, 321-378`); tested through a real child script boundary (9 cases, executed by me under pwsh 7.6.6: PASS; see section 11 for Windows PowerShell 5.1). |
| REPLAY-SUBPROCESS-DEADLINE | checkable now | CHECKED on Windows; POSIX branch unexecuted (inconclusive by host). Every subprocess goes through `Invoke-RMQOwnedBoundedProcess` (`owned_process_tree.ps1:333`, kill-on-close job object), exits and stderr preserved (known-failure control exit 23 with stderr marker: PASS), timed-out sleeper with a real descendant confirmed absent (PASS at 45 s; author needed 30 s after a 12 s default failed), restoration in `finally` (`:462-483`) with raw byte hash, registry hash, restored firewall/producer/consumer and full Git state comparison. |
| INV-STORE-IDENTITY | adequacy, construction open | Not closable now. Contract pins RHS and initial states; emitted-cell extraction unpinned (P1-3, A3). |
| INV-VALUE-DEPENDENCY | adequacy, construction open | Per-primitive provenance is checked now: `store_value_from_prestate` (`Primitive.lean:183-186`) pins address and value to the prestate registers; `oracle_not_reflected` contradiction is in the returned register projection, not a log. Run-level provenance (write analogue of `positionalReadBacking`) is a future row; A3 keeps the LHS from bypassing it. |
| INV-SEMANTIC-NONVACUITY | CHECKED on contract artifacts | `CleanTail`, `Uniform`, `SignedFits`, `InputFits`, `OperandsFit32` are genuine predicates derived from the operational definitions; `CodeAccounting program width bits := bits = programWords program * width` is definitional and satisfiable by `rfl`, so its content is that `programWords` is the actual flattened constant count; the consumer expands both (`check.lean:40-44`) and replay cases C15/C16 reject the `True`/zero aliases. No `True`-valued predicate is advertised. |
| INV-TRACE-EXECUTION | adequacy, construction open | No trace type exists yet; `Replays` (`Controls.lean:105-106`) is plain data and disclaimed (FK-7). Future traces must come from `checkedStep` iteration (CONTRACT.md:107-117). |
| INV-STORE-AGREEMENT | adequacy, construction open | `Conservative.execute_eq` shows single-step agreement with the old interpreter on the same memory; run-level supplied-store agreement is a future row consumed via the PQ1 `suppliedMemoryAgreement` field after A3. |
| INV-READ-BACKING | adequacy, construction open | `load` faults outside `extent` and on absent cells (`Primitive.lean:128-133`), so successful reads are backed by present cells now; positional run-level backing is future. |
| INV-WORD-WIDTH | adequacy, construction open | Not enforced by the model (unbounded `Nat`); encoded input words fit under `InputFits` (`encodeInput_word_fits`); everything reachable is the future safety row (P2-2). Contract states this correctly (CONTRACT.md:85-87, 94-96). |
| INV-ADDRESS-WIDTH | CHECKED on operand syntax; run open | Every encoded operand, register identifier, branch/jump target, immediate and tag is `Fin (2^32)` or a small tag in `Prim.constants` (`:65-83`, constructor-exhaustive, no wildcard; `prim_const_cap` is `c.isLt`; `constants_fit_width` lifts to any width ≥ 32). Dynamic addresses (`s.regs address`, `jumpRegister`) are unbounded `Nat` and are the future row. |
| INV-INSTRUCTION-ATOMICITY | CHECKED per arm; conditional on width row | All 13 `execPrim` arms inspected (section 6, CONTROL-PQ): no recursion, no host-list traversal, no decoding, no RMQ semantics; each arm is one register/memory/extent/pc/status update. `interpretPrims` recursion is over the singleton reflected list only. The unbounded-`Nat` arithmetic is atomic only under the future safety row (P2-2). |
| INV-PROGRAM-ACCOUNTING | CHECKED on schema; A2 | `programWords` counts tags, sub-tags, immediates, registers and targets (`Controls.lean:94-95`); `CodeAccounting` at width; `Uniform` excludes input-indexed code; immediates are `Fin (2^32)` so a K-bit table costs about K/32 counted instructions. Width/size indexing excluded by prose only (P1-2). |
| INV-ORACLE-INDEPENDENCE | CHECKED on controls | Oracle expected values 5/3/5 come from the existing `Cartesian.stackCartesianShape` BP serialization (`Shape.lean:942`, `:47`), an independent specification, proved by `simp` unfolding (`Controls.lean:37-54`). Consumer boundary examples (`check.lean:76-79`) are `decide`d from the definition under test and are illustrations, not fixtures. |
| INV-VALIDATION-REACH | P2-1 | The consumer and replay import and elaborate the new layer; no gate/CI does (A4). No predecessor validator is presented as evidence for the new machine. |
| INV-ALL-SIZE | adequacy; n=0 checked where stated | `Uniform` quantifies over every `xs` including `[]`; `header_read`/`missing_header_fault` hold for `xs = []` (extent 1, header only); `encodeInput_eq_none_iff` gives the exact extent; target has 174 metadata words at every size (FK-16). No readiness dispatch exists. |
| INV-PROOF-SEPARATION | CHECKED | `ContractPrerequisites` and `ProgramContract` are `Prop` structures with no data fields; `Conservative.instruction` consumes an erased bound proof only for `Fin` construction; `BInstr` carries no evaluator. |
| INV-NO-SYNTHETIC | adequacy | `Replays` is explicitly not evidence (CONTRACT.md:170-173); no synthetic event type exists. |
| INV-CATEGORY-SEPARATION | CHECKED | Machine state (`regs`, `memory`, `extent`, `pc`, `status`), oracle channel (`keys`, `keyRegs`), code words (`programWords`), model ticks (future, per transition) and Lean runtime (functional updates, disclaimed at `Primitive.lean:5-7`, CONTRACT.md:115-116) are distinct; no measured-performance claim exists. |
| INV-PUBLIC-COMPOSITION | adequacy, construction open | Contract requires one capstone over the same `xs`, program, store, width, run and query (CONTRACT.md:192-200); A3 prevents composing over a sibling store. |
| INV-CERTIFICATE-ANTI-BYPASS | CHECKED | All ten `ContractPrerequisites` fields and all four `ProgramContract` fields are projected at fixed full types (`check.lean:10-54`, section 9); `contractPrerequisites_holds := {}` (`Contract.lean:49`) is inhabited only through the ten default proofs, each a named theorem; nine `#print axioms` cover the record and every load-bearing producer; deletion (C11), weakening to `True` (C01-C10, C12), sibling substitution (C13) and alias/count mutations (C15, C16) break the consumer at the pinned line in my replay. |
| INV-MUTATION-REPRODUCIBILITY | CHECKED | Versioned runner and registry replay all 18 cases with exact stage/line surfaces, restore bytes and Git state, leave the tree clean; reproduced by me in a clean detached copy at the exact target (section 11). The public-dependency consumer is `check.lean`, which fails when a field is removed; `#print axioms` is additional, not the consumer. |
| INV-GLOBAL-PHYSICAL-MACHINE | adequacy, construction open | One pre-execution store exists per model (`wordInputState`/`comparisonInputState`); address translation for every executed segment is the future run row; Conservative bridge is single-step, not a whole-machine embedding, and CONTRACT.md:119-123 says so. |
| INV-WIDTH-SCALING | adequacy; correctly disclaimed | `inputFits_all_sizes` uses width n+2 and is labelled satisfiability only (`Input.lean:167-168`, CONTRACT.md:74-77); the capstone must instantiate `wordWidth xs.length` (CONTRACT.md:76-77); one width must bound all operands, results, addresses, sentinels (future safety row, P2-2; A2 prevents width-indexed code). |

## 5. Verification coverage summary (what was run)

| Check | Result |
| --- | --- |
| Identity: HEAD, clean status, autocrlf, toolchain, prompt SHA | PASS (section 1) |
| Preflight | PASS 3.807 s |
| Frozen 31-row/31-section byte integrity across three trees | PASS (section 4) |
| Historical inputs at base: `RMQ_PROGRAM_PLAN.md`, `wf3_attack.json` | blobs identical at base and target (37eaaae3..., 91bfeafa...); worktree CRLF SHA-256 E66111A9545DA6C8E9F472BBAFCF81C3752AD734961853C9612EF8F07B113B86 and F26087549E6AB0B5A8A43423474F42509CCA2720DE93ED761840DD02660B44E6 match the prompt |
| AMENDMENTS.md quotation fidelity (12 rows + R1/R2/R12/R13) | PASS: all 16 fenced `text` blocks are byte-identical (after CR stripping on both sides) to plan lines 271-282 and to the four `required_repairs` strings in the JSON (my script `amend_check.ps1`) |
| Static reconstruction of every listed declaration | done (sections 6, 9) |
| Explicit build `lake build RMQ.Core.WordRAM.Construction.Contract` (heavy 1, audit tree, cold) | exit 0, 77.207 s, 16 modules (Std-only roots plus `RMQ.Core.{ListLemmas,Spec,Window,Backend,LCA,Reduction,Cartesian,Shape}` and `Packed.Primitive`); `-j1` attempt rejected in 0.274 s |
| `lake env lean scripts/preprocessing_contract_check.lean` | exit 0, 2.670 s, nine axiom lines, `PRE1-CONTRACT-TYPED-CONSUMERS PASS` |
| Header-leak probe | compiled, exit 0, 2.272 s (P1-1) |
| Replay `-RegistrySelfTestOnly` / `-SelectorBoundarySelfTestOnly` / `-DeadlineSelfTestOnly` (copy, pwsh 7.6.6) | PASS 4.002 s / PASS 25.241 s / PASS 50.888 s |
| Replay `-StartupOnly` / `-OnlyCase C01_REFLECTION` / full 18 (copy) | PASS 106.874 s / PASS 56.381 s / PASS 667.335 s (executed = expected = 18, 198 stages, 28 self-tests, no timeouts, clean tree before and after) |
| Windows PowerShell 5.1 registry and selector self-tests (copy) | see section 11 (PS5 row) |
| Trust hygiene rg scans (Construction, consumer, whole `RMQ/`, `lakefile.toml`) | no matches (rg exit 1) for both patterns |
| Evidence identity (section 12) | all archive and source hashes match |
| Report-sensitive checks (section 17) | recorded in section 17 |
| Not run (coordinator-owned or host-unavailable) | full default `lake build`; `scripts/gate.ps1`; POSIX/WSL branch of the process tooling; any build in the author worktree |

## 6. Ten contract-specific obligations

### AMENDMENT-INTENT — disposition: SURVIVES WITH FUTURE OBLIGATIONS; A1, A2, A4 required to make three prose-only survivals checkable

Quotation fidelity: PASS; every "Exact old plan row" and every R-clause block in
AMENDMENTS.md is byte-identical to the historical source (section 5). The
historical bytes are unchanged between base and target (same blobs). Per
obligation (details in section 8): O-UNIF's all-size strict information gap is
dropped for a correct reason (false at n = 0: the target has 174 metadata words
while PQ1's fixed query program is 837,572 instructions at a 32-bit width floor,
`QueryStatic.lean:68`, `Allocation.lean:23`); it is compensated by counted code
(`programWords`/`CodeAccounting`), literal pins in `ProgramContract`, and the
same `Uniform` predicate used by `baked_not_uniform` (`Contract.lean:19`,
`Controls.lean:89`). Residual: the pins are `Nat` parameters and `family` is free
(P1-2, A2). "A fixed finite constant table is counted, not forbidden"
(CONTRACT.md:41-45) admits only tables inside the one fixed program, counted at
width; an input-size- or shape-indexed table would make the family differ on
some `xs` and fail `Uniform`; a preseeded memory table is excluded by
`wordInputState_cleanTail` (`Model.lean:59-64`) via `encodeInput_eq_none_iff`.
The only route back in is width-indexing (A2). The getBit/setBit and
mulConst/divConst vocabulary is replaced by the accepted PQ1 arithmetic set
{add, sub, mul, div, mod, shl, shr, band, bor, bxor} with `Fin (2^32)`
immediates (stronger than the historical `c < 2^wordBits`); no arm does
non-constant work as a Lean term, but the unbounded-`Nat` denotation means the
constant-work reading holds only under the future safety row (P2-2). O-POINTWISE
header clause: available, not forced (P1-1, A1). O-FIREWALL: closure tightened
from a path set to per-file exact allowlists plus frozen evaluator bytes, but
"CI-enforced" became "replay-enforced" (P2-1, A4). O-CONTROL: the `forall s` form
is equivalent to the historical function equality by extensionality, and the
baked exhibit correctly moves from "violates the gap" to "fails `Uniform`".
O-REPLAY/R11/FK-7: still disclaimed (CONTRACT.md:170-173, `Controls.lean:103-104`).
O-BITS/O-WRITE/O-SCRATCH/O-REPR/O-COUNT/O-NOINHERIT: strengthened or preserved,
each with its future row named (section 8). R13's freeze order is preserved
(this audit is that node); its ISA-widening concern is what A4 addresses.

### CATALOGUE-15 — disposition: 15/15 dispositions independently reconstructed; all follow from frozen or amended text; two ATTACK_TABLE rows name the wrong basis

Table in section 7. Distinct identifiers verified from the JSON: FK-1..FK-9,
FK-11..FK-16 (FK-10 absent), 25 comparison rows. Already-checked rejections:
FK-4 (pointwise/clean initial states), FK-7 (non-claim), FK-13 (producer exists),
FK-16 (target nonempty at every size), the primitive-level halves of FK-2, FK-3,
FK-5, FK-8, FK-14. Future builder obligations: FK-1, FK-6, FK-9, FK-11, FK-12,
FK-15 and the run-level halves. FK-11 checked against this very phase: nothing
here descopes-and-claims (every REQ/INV row OPEN; CONTRACT.md:15). FK-12: no
`Safe`/`Fits` analogue exists yet; the future width row must cover written
values, not only addresses (P2-2). FK-13: `fullyChargedPackedQueryCapstone_holds`
exists at `Packed/Capstone.lean:173-174` with the 33 fields listed in section 9.

### CONTROL-PQ — disposition: controls are true, exactly as stated, meaningful within their explicit limits

`oracle_not_reflected` (`Controls.lean:60-61`):
P (accepted positive, what any accepted one-step instruction satisfies) is
`∀ i s, bstep i s = interpretPrims i.semantics s` with `i.semantics = [i.primitive]`, `primCap = 1`;
Q (rejected mutation) is exactly
`∃ ps : List Prim, ps.length ≤ primCap ∧ ∀ s, interpretPrims ps s = oracleSemantics s`,
where `oracleSemantics s := s.writeNext 0 (oracleBPWord s)` and
`oracleBPWord s := (Cartesian.stackCartesianShape [(s.keys 0).getD 0, (s.keys 1).getD 0]).bpCode.foldr (fun b acc => (if b then 1 else 0) + 2 * acc) 0`.
This Q is the O-CONTROL proposition up to function extensionality (historical
`interpretPrims ps = oracleSemantics`). Proof: `execPrim_numeric_independent`
(`:13-17`) is universal over `p : Prim`, `s : State`, `otherKeys`, proved by
`cases p` over all 13 arms with `split` on the `load`/`store`/`loadKey` matches;
`capped_numeric_independent` (`:19-27`) lifts it to `ps.length ≤ 1`; the
contradiction instantiates `s := comparisonInputState [0, 1]` and the same state
with keys of `[1, 0]` (`hs : ... = comparisonInputState [1, 0] := rfl`) and uses
`oracle_increasing : ... = 5`, `oracle_decreasing : ... = 3` at register 0. The
argument is universal over states; the two instances are the witnesses of the
negation, which is the correct shape for `¬ ∃`.
Is `bstep_reflects` trivial? Yes: `bstep i s := execPrim i.primitive s` and
`interpretPrims [p] s = execPrim p s`, so it is `rfl`, and `semantics_cap` is
`simp`. Their content is structural: a `BInstr` is exactly one `Prim` and has no
evaluator field (`Primitive.lean:155-158`), so the only way to add work is to add
a `Prim` constructor arm, which the exhaustive `Prim.constants`/`Prim.category`
matches and the frozen evaluator bytes surface. O-WORKCAP's intent therefore
holds because `Prim` is finite constructor data with scalar arms, checked by arm
inspection, not because the reflection theorem is deep; CONTRACT.md:146-147
concedes this. Limit: the control depends on `primCap = 1`; the sequence
`loadKey; loadKey; compareKey` does move key order into a numeric register in
three ticks, which is exactly the charged route the model intends.
Arm inspection (`execPrim`, `:126-153`): load (extent guard, `Option` match, one
register write or fault), constant, move, arithmetic (`Arithmetic.eval`),
comparison (`Comparison.eval`), jump, jumpRegister, branchZero, halt, store
(extent guard, one `put`), reserve (one register write, `extent + 1`, memory
unchanged: `reserve_does_not_initialize`), loadKey (`keys` lookup into `keyRegs`
or fault), compareKey (strict `<` on two `keyRegs` into a numeric register). No
arm recurses, scans a list, decodes, or names an RMQ function. `Arithmetic.eval`
and `Comparison.eval` are the accepted PQ1 evaluators verbatim; division,
remainder and shifts are present with the same denotation, and the same future
`Safe` row is needed (P2-2). The canonical two-key BP-word exhibit is kept
explicit as not a full PQ1 cell (CONTRACT.md:165-167; matrix appendix :345).
`baked_not_uniform` (`:89-92`): P = `Uniform program family := ∀ xs, family xs = program`;
Q = `∃ program, Uniform program bakedProgram` with
`bakedProgram xs := [⟨.constant 0 (if (xs[0]?).getD 0 ≤ (xs[1]?).getD 0 then 5 else 3)⟩, ⟨.store 1 0⟩]`,
refuted by `bakedProgram [0, 1] ≠ bakedProgram [1, 0]` (`decide`); `baked_length`
shows the family has constant length 2, so the rejection is by content, not
size.

### HEADER-AND-LENGTH-LEAK — disposition: LEAK CONFIRMED BY COMPILED PROBE; amendment A1 required

See P1-1. `ProgramContract` fields (`uniform`, `lengthPinned`, `encodedPinned`,
`codeBits`) say nothing about memory reads. `reserve` exposes `extent`, which
is `n + 1` in `wordInputState`; the probe `lengthLeakProgram` inhabits
`ProgramContract` at literal pins, recovers `n` in every width model state,
keeps running when cell 0 is absent, and contains no `load`. No current theorem,
consumer or guard rejects it. In the comparison model the same program yields
0. Exact amendment stated in section 2 (A1).

### FIREWALL-PLACEMENT — disposition: closure sound for the three roots; reuse question answered; parser bypass not found; wiring gap (A4)

Reuse: a future run module inside the closure cannot import Controls (Shape
import, oracle host) and does not need to: `Program` is an abbreviation for
`List BInstr`; `Uniform`, `programWords`, `CodeAccounting` are only consumed by
Contract/Capstone, which sit outside the closure and already import Controls.
Recommended R3 to state this. Parser bypass attempts (by reading
`Remove-LeanComments`, `firewall.ps1:17-46`): an import after a comment is still
matched because comments are blanked and `(?m)^\s*import` matches any line; an
import hidden inside a string or char literal cannot compile because Lean
requires imports before any command; `prelude` and stray `import` tokens fail
the `\b(import|prelude)\b` residue check (`:64-67`); transitive imports through
Input are closed because Input's own allowed list is `Std`; `open`/`export`
cannot import. A multi-module `import A B` line is split on whitespace and
compared exactly (`:53-59`). Manifest: version 1, exactly 3 entries, paths
must be allowlist keys, SHA-256 of CRLF-to-LF normalized strict UTF-8 bytes
compared case-sensitively (`:69-88`); I recomputed all three hashes (match). The
firewall runs before compilation in `Invoke-Compile` (`replay.ps1:157-163`), a
nonzero firewall exit stops the case at the firewall stage, and its diagnostics
are exactly `PRE1-FIREWALL imports rejected: <path> actual=[...]` and
`PRE1-FIREWALL frozen primitive bytes changed: <path>` (observed in my C17/C18
runs, section 11). Gap: no gate or CI invokes it (P2-1, A4).

### INPUT-MODEL — disposition: CHECKED, as specified

Header unsigned: `encodeInput width xs 0 = some xs.length` (`Input.lean:80-82`);
keys biased-signed: `encodeInt width x = (x + 2^(width-1)).toNat` (`:23-24`) applied
only to `xs[address-1]?` (`:31-33`). Guards: `encodeInt_asInt`, `encodeInt_lt_capacity`
take `SignedFits width x`; `encodeInt_le_iff/lt_iff/eq_iff` take `SignedFits` on
both operands; `encodeInput_word_fits`/`encodeInput_address_fits` take
`InputFits width xs`; `zero_inputFits` takes `0 < width` and `n < 2^width`. No
order or capacity theorem lacks its guard. `inputFits_all_sizes n : InputFits (n+2) (replicate n 0)`
is labelled a witness only (`:167-168`, CONTRACT.md:74-75, matrix appendix :341).
`comparisonInputState` names the arbitrary-Int model with `keys := fun i => xs[i]?`,
numeric memory holding only the header, `loadKey` (category `keyRead`) and
`compareKey` (category `oracleComparison`) as separate charged primitives; in
the word model `keys := fun _ => none`, so `loadKey` always faults there. No
sorting, ranking or rank-conversion function exists in the three roots (rg over
the closure: none). One note: `compareKey` provides only strict `<`; `≤`/`=`
must be derived in the program by two comparisons, which is a modelling choice,
not a gap.

### CONSERVATIVE-BRIDGE — disposition: SCOPE CORRECT AND NOT OVERCLAIMED

`execute_eq_of_fits memory i (hfit : i.Fits 32) s (hrun : s.status = .running) : execPrim (instruction i _) (state memory s) = state memory (PackedWordRAM.execute memory i s).1`
(`Conservative.lean:164-168`): the `.1` is the state component only; the receipt
(`.2`) is not bridged; the prestate must be running because the old `writeNext`
resets status (`:106-108`); operand bound premise is the accepted `Fits 32`
lifted through `operandsFit32_of_fits` (`:83-88`). `execute_eq` covers all nine
old constructors including both `load` outcomes. CONTRACT.md:119-123 calls it "a
separate semantic bridge ... It does not edit PQ1 or prove a builder execution";
the matrix appendix (:343) says "not a query-simulation/cost theorem". No
receipt, cost or trace preservation is claimed anywhere. Consumer
`conservative_step` (`check.lean:81-87`) restates the full type.

### CONSUMER-ANTI-BYPASS — disposition: CHECKED; nine axiom prints observed with standard axioms only

Field-by-field expansion in section 9. Every `ContractPrerequisites` field is
projected at its full stated type at `check.lean:10-38`; every `ProgramContract`
field at `:46-54` (universally over `program family k b`); the code-accounting
alias and count are expanded to the raw expression at `:40-44`.
`contractPrerequisites_holds := {}` is inhabited solely from the ten default
proofs `bstep_reflects`, `semantics_cap`, `constants_fit_width`,
`⟨header_read, missing_header_fault⟩`, `encodeInput_succ`, `oracle_not_reflected`,
`baked_not_uniform`, `store_value_from_prestate`, `reserve_fresh`,
`code_accounting_exact`; none assumes an output equality. Observed axiom prints
(my run): `contractPrerequisites_holds` [propext, Classical.choice, Quot.sound];
`oracle_not_reflected` [propext, Quot.sound]; `baked_not_uniform` [propext];
`header_read` [propext]; `encodeInt_lt_iff` [propext, Classical.choice, Quot.sound];
`inputFits_all_sizes` [propext, Quot.sound]; `reserve_fresh` [propext, Quot.sound];
`comparison_missing_header_fault` [propext]; `Conservative.execute_eq_of_fits`
[propext, Quot.sound]. The nine cover the record (hence all ten fields
transitively) and the load-bearing standalone producers. Declarations consumed
by typed theorems in the same file but not printed on their own
(`comparison_header_read`, `checkedStep_fault`, `checkedStep_halted`,
`fabricated_replay_rejected`, `encodeInt_lt_capacity`) are proved by `simp`
over the definitions in the audited Std-only modules, which I read; adding
them to the print list in the builder phase is recommended (P3). The consumer
does not itself assert the axiom set, and the replay matches the printed
consumer text only for the PASS marker and the pinned error lines, so the
standard-axiom property rests on inspection of the printed output (done here:
nine lines, only `propext`, `Classical.choice`, `Quot.sound`).

### REPLAY-18 — disposition: REPRODUCED IN A CLEAN DETACHED COPY AT THE EXACT TARGET (18/18, executed = expected, every case at its pinned stage and surface, exact restoration); see section 11

Registry read: version 1, 18 cases in the frozen order C01_REFLECTION ..
C18_PRIMITIVE_BYTES; content hash `aaec37a62bc74b483d09362a5d16f62afc2ae3a7be007577bc13e4c87c98574e`
recomputed from my CRLF worktree bytes after CRLF-to-LF (raw CRLF hash
85eaffcd...). Each case pins `expectedStage` and, for consumer rejections, the
exact `preprocessing_contract_check.lean:<line>:` surface (regex-enforced,
`replay.ps1:97-100`); registry paths are a closed set of six files (`:102-110`).
Producer-before-consumer and firewall-before-producer order: `Invoke-Compile`
(`:155-179`). Restoration in `finally` with byte hash, registry hash, restored
compile of all three stages, source hashes and Git state (`:462-483`). Owned
bounded subprocesses: `Invoke-Stage` calls `Invoke-RMQOwnedBoundedProcess`
(`:126-140`; `owned_process_tree.ps1:333`, Windows kill-on-close job). Selector
boundary: `Select-Cases` (`:117-124`) distinguishes omitted from bound-empty via
`$PSBoundParameters`. Deadlines I used and their basis: author `replay-full.zip`
per-stage maxima firewall 15.20 s (n=37), producer 23.07 s (n=35), consumer
17.63 s (n=35), git 7.92 s (n=80), selector 16.93 s (n=9), owned-descendant
30.35 s at 30 s; my cold contract build 77.207 s. Chosen:
`-DeadlineSeconds 600` (≥ 2× cold build), `-AdministrativeDeadlineSeconds 120`
(≥ 2× 16.93), `-SleeperDeadlineSeconds 45` (author's working 30 s plus margin;
the 12 s default is documented as failing on this host's ~9 s shell startup),
`-LakePath C:/Users/poin/.elan/toolchains/leanprover--lean4---v4.22.0/bin/lake.exe`.
The runner itself passes `LEAN_NUM_THREADS=1`. A timeout would have been
recorded as inconclusive; none occurred.

### EVIDENCE-IDENTITY — disposition: ALL INDEXES MATCH ARCHIVE BYTES AND CURRENT SOURCE (normalized); delta is docs/evidence only

Section 12.

## 7. The 15-case catalogue

CN = rejection already checked now (theorem/guard named); FB = future builder
obligation (rejecting row named). All rejections follow from frozen or amended
text; column (e) records disagreement with ATTACK_TABLE.md.

| FK | Attack (from `wf3_attack.json`) | Rejecting obligation / frozen row and decisive clause | Status | vs ATTACK_TABLE.md |
| --- | --- | --- | --- | --- |
| FK-1 | Hand-built record `{payload, finalStore, dummy trace}` with no run | REQ-PRE-EXACT "exact ordered output equality ... from that same run"; REQ-PRE-MACHINE "against that interpreter"; INV-TRACE-EXECUTION; INV-NO-SYNTHETIC | FB (run identity; `fabricated_replay_rejected`, `Controls.lean:108-112`, only shows the toy `Replays` is falsifiable) | Table cites O-REPLAY, whose own text disclaims any kill (AMENDMENTS.md:147); basis should be run identity |
| FK-2 | Oracle constructor in the interpreter | REQ-PRE-MACHINE "Isolate interpreter semantics from RMQ imports"; O-FIREWALL replacement "Primitive and Input directly import Std only" | CN for `execPrim` (Std-only import, 13 scalar arms, `firewall.ps1:9-15, 53-67, 69-88`); FB for the not-yet-existing fetch/run module (must be added to the allowlist, CONTRACT.md:139-140; A3/A4) | "O-WORKCAP" adds nothing here: `bstep_reflects` stays `rfl` if an oracle arm is added; the kill is imports plus bytes plus arm inspection |
| FK-3 | One instruction doing unbounded work | REQ-PRE-MACHINE "Charge each read, write, arithmetic/comparison ..."; INV-INSTRUCTION-ATOMICITY | CN for macro constructors (exhaustive scalar arms); FB for the unbounded-`Nat` big-register route (REQ-PRE-COST value bounds, INV-WORD-WIDTH, INV-WIDTH-SCALING; P2-2) | Table's "literal cap 1" is definitional and does not address per-tick denotational work |
| FK-4 | Payload smuggled in the encoded input or preseeded cells | O-POINTWISE replacement "Cell i+1 is (xs[i]?).map(encodeInt width)"; O-NOINHERIT "All non-input memory initially absent ... all registers zero"; REQ-PRE-INPUT "pointwise element cells" | CN: `encodeInput` (`Input.lean:31-33`), `encodeInput_eq_none_iff` (`:95-101`), `encodeInput_word_fits` (`:103-115`), `wordInputState`/`_cleanTail` (`Model.lean:39-46, 59-64`), `comparisonInputState` (`:50-57`); FB: builder theorems must be stated on exactly these states (INV-STORE-IDENTITY) | Agree |
| FK-5 | Size/shape-indexed program family; cheap variant bakes fixed tables | O-UNIF replacement "One closed finite program for all xs ... Size/shape-dependent families fail the actual Uniform predicate"; REQ-PRE-MACHINE; INV-PROGRAM-ACCOUNTING | CN for the control (`Uniform`, `baked_not_uniform`); FB for the real instance (parameterless declaration, literal pins: A2). Cheap variant: reclassified as counted code inside the one program (CONTRACT.md:42-45), not forbidden | Table says "Forbidden" without stating the reclassification |
| FK-6 | Decorative run; output defined semantically; `rfl` bridge | REQ-PRE-EXACT "Pure semantic builders ... may not run outside the charged implementation"; INV-VALUE-DEPENDENCY | FB; structurally killed only if `efficientBuild` is inside the closure (A3) | Agree; add that no BR-F1 analogue exists yet (A3) |
| FK-7 | Replay advertised as anti-oracle | O-REPLAY replacement "Replay is necessary and insufficient"; CONTRACT.md:170-173 | CN as a non-claim; the plan's residual (does the distribution across O-UNIF/O-FIREWALL/O-WORKCAP/O-NOINHERIT/O-POINTWISE suffice?) closes only with the two open links: run module inside the firewall (A3/A4) and the width row (P2-2) | Agree |
| FK-8 | Correct addresses and counts, oracular values | O-WRITE replacement "positional address/value provenance"; INV-VALUE-DEPENDENCY | CN per primitive: `store_value_from_prestate` (`Primitive.lean:183-186`), `store_other_unchanged`, `reserve_does_not_initialize`; FB: run-level write provenance (write analogue of PQ1 `positionalReadBacking`) | Agree |
| FK-9 | Padding as a free parameter | O-BITS replacement "Exact ordered numeric output equality ... No fittable padding parameter"; REQ-PRE-EXACT | FB; `buildMemory` is a concrete list, so no slack term can exist | Agree |
| FK-11 | Build one component, keep obligations "stated unchanged" | REQ-PRE-EXACT "Build the full pipeline ... including 174 metadata words"; REQ-PRE-JOIN "One capstone"; INV-PUBLIC-COMPOSITION; matrix :100-102 "never CANDIDATE_COMPLETE" | FB; this phase itself does not descope-and-claim (CONTRACT.md:15; all rows OPEN); both input models required separately | Agree |
| FK-12 | Width certificate covers addresses only | INV-WORD-WIDTH "stored and returned words fit"; INV-ADDRESS-WIDTH; INV-WIDTH-SCALING; REQ-PRE-COST | FB: no `Safe`/`Fits` analogue exists; `constants_fit_width` bounds syntax only (P2-2) | Table's "bounded constructor constants ... are checked" is true by type and does not touch the attack |
| FK-13 | Join cites a nonexistent query theorem | REQ-PRE-JOIN "efficientBuild equality -> PQ1 fullyChargedPackedQueryCapstone_holds" | CN for existence (`Packed/Capstone.lean:173-174`, 33-field record over `buildMemory xs`); FB for the composition | Agree |
| FK-14 | Unbounded scratch | REQ-PRE-COST "peak temporary workspace <= Cw*n+Dw words, with all mutable storage ... separately accounted"; O-SCRATCH replacement removes the non-claim option | CN structurally for memory (`load`/`store` fault outside `extent`; `extent` grows one cell per `reserve`); FB for registers (`Registers := Nat → Nat`, unbounded storage outside `extent`/`CleanTail`) and for the constants | Table omits the register file as scratch |
| FK-15 | Giant fuel as oracle | REQ-PRE-COST "explicit all-size constants C,D with executed work <= C*n+D" | FB; residual non-claim: no magnitude bound on C, D (explicit non-optimality stance) | Agree |
| FK-16 | Both stores empty on the footprint | REQ-PRE-EXACT "including 174 metadata words"; INV-STORE-IDENTITY | CN for target nonemptiness (`metadata_length`, `Allocation.lean:142-152`; `buildMemory xs = shapeMemory (cartesianShape xs)`, `:157-158`); FB for the equality | Agree |

## 8. Amendment-by-amendment intent comparison

Quotation fidelity: PASS (16/16 blocks byte-exact). Tiers: T theorem/definition,
G production guard, P prose.

| Clause | Historical (plan C.2 / JSON) | Replacement (AMENDMENTS.md / CONTRACT.md) | Intent for all n incl. 0, with PQ1 fixed code | Evidence tier |
| --- | --- | --- | --- | --- |
| O-UNIF | closed constant, `rfl` length, all-size code bits < payload | closed program for all xs incl. `[]`; literal instruction/encoded-word pins; counted code; absorption eventual | SURVIVES with future obligation: parameterless declaration and numerals pinned by the builder consumer (A2) | T `Uniform`, `ProgramContract`, `programWords`; P "unparameterized" |
| O-WORKCAP | 11-constructor `Prim` with `mulConst/divConst (c : Nat)`, getBit/setBit, three theorems, `c < 2^wordBits` | 13-constructor `Prim` over `Fin (2^32)`, singleton semantics, `primCap := 1`, `bstep_reflects`, `constants_fit_width` (W ≥ 32); PQ1 arithmetic preserved | SURVIVES with future safety row (P2-2) | T `Primitive.lean:15, 47-83, 156-178`; `Model.lean:31-35` |
| O-BITS | sequence equality to `canonicalSegmentWords` + width row | exact ordered equality to `buildMemory xs` | SURVIVES (stronger); FB REQ-PRE-EXACT; LHS pin needed (A3) | P |
| O-SCRATCH | bounded or absence stated | mandatory `<= Cw*n + Dw` words | SURVIVES (stronger); FB REQ-PRE-COST | T `CleanTail` family; P bound |
| O-REPLAY | non-goal | non-goal, load-bearing rows named | SURVIVES | P; toy T `fabricated_replay_rejected` |
| O-NOINHERIT | REQ-BLD-06 third conjunct | zero registers, memory absent beyond extent, `CleanTail`, cells only from stores | SURVIVES for initial states; run-level preservation future | T `wordInputState`, `_cleanTail`, `reserve_fresh` |
| O-POINTWISE + R1 header | signed header via `encodeInt wordBits xs.length`, cells shifted; "length arrives in a register read from a pinned header cell" | unsigned header `some xs.length`; cell i+1 pointwise; "missing header faults for all lengths" | SURVIVES for the encoding (the unsigned/signed split is a genuine repair: a biased header would read as an offset length); header USE not forced (P1-1, A1) | T `Input.lean:31-33, 80-87`; T `Model.lean:74-96`; P "obtained by the actual load" |
| O-FIREWALL | closure `{Cost, RAM, WordRAM}`, CI-enforced | per-file exact allowlists + frozen bytes; consumers outside | SURVIVES as a guard; "CI-enforced" dropped (P2-1, A4) | G firewall; not in gate/CI |
| O-CONTROL + R12 | `¬ ∃ ps, len ≤ primCap ∧ interpretPrims ps = oracleSemantics`; baked builder violates R1 gap | same with `∀ s`; baked family fails `Uniform` | SURVIVES; equivalent proposition; baked exhibit re-targeted correctly | T `oracle_not_reflected`, `baked_not_uniform` |
| O-REPR | signed representability, order refinement, all-size family, else "comparison oracle" wording | two mandatory corollaries (Int oracle / finite-key word) | SURVIVES (stronger); logarithmic common width future | T `Input.lean:18-20, 51-78, 159-173`; T `loadKey/compareKey` |
| O-WRITE | units stated; emission and packing joined | per-primitive units; reserve and store separately charged; one run | SURVIVES; run-level provenance future | T `Prim.category`, `store_value_from_prestate` |
| O-COUNT | five wrappers / eight tables; no 2n forecast | preserved; retained-space sentence only through exact equality | SURVIVES | P (SOURCE_FACTS inventory) |
| R2 | reflected ISA, literal cap, bounded constants, compile-time exhaustiveness | as O-WORKCAP | SURVIVES (wildcard-free matches at `Primitive.lean:65-83, 90-103, 126-153`) | T |
| R13 | freeze order: R1/R2/R5/R12 audited before builder | preserved (CONTRACT.md:3-6, 203-211) | SURVIVES as process; ISA-widening guard is replay-only (A4) | P |

## 9. Statement and consumer reconstruction

`ContractPrerequisites` (`Contract.lean:25-47`), each field's exact type and the
default proof, and the consumer line that restates it:

| Field | Exact proposition | Default proof | Consumer line |
| --- | --- | --- | --- |
| reflection | `∀ i s, bstep i s = interpretPrims i.semantics s` | `bstep_reflects` (rfl) | `check.lean:10-11` |
| workCap | `∀ i : BInstr, i.semantics.length ≤ 1` | `semantics_cap` | `:12-13` |
| constantCap | `∀ (i : BInstr) (p : Prim), p ∈ i.semantics → ∀ c ∈ p.constants, ∀ width, 32 ≤ width → c.val < 2 ^ width` | `constants_fit_width` | `:14-15` |
| headerRead | `∀ width xs, ((bstep headerInstruction (wordInputState width xs)).regs 1 = xs.length ∧ ... .status = .running) ∧ (bstep headerInstruction { wordInputState width xs with memory := put (encodeInput width xs) 0 none }).status = .fault` | `⟨header_read, missing_header_fault⟩` | `:16-21` |
| pointwise | `∀ width xs i, encodeInput width xs (i + 1) = (xs[i]?).map (encodeInt width)` | `encodeInput_succ` | `:22-24` |
| oracleControl | `¬ ∃ ps : List Prim, ps.length ≤ primCap ∧ ∀ s, interpretPrims ps s = oracleSemantics s` | `oracle_not_reflected` | `:25-27` |
| uniformControl | `¬ ∃ program, Uniform program bakedProgram` | `baked_not_uniform` | `:28-29` |
| writeValue | `∀ address value s, s.regs address < s.extent → (execPrim (.store address value) s).memory (s.regs address) = some (s.regs value)` | `store_value_from_prestate` | `:30-32` |
| freshReserve | `∀ s, CleanTail s → ∀ dst, (execPrim (.reserve dst) s).memory s.extent = none` | `reserve_fresh` | `:33-35` |
| codeAccounting | `∀ program width, CodeAccounting program width (programWords program * width)` | `code_accounting_exact` (rfl) | `:36-38` |

`ProgramContract program family instructionLiteral encodedWordLiteral : Prop`
(`Contract.lean:17-22`): `uniform : Uniform program family`;
`lengthPinned : program.length = instructionLiteral`;
`encodedPinned : programWords program = encodedWordLiteral`;
`codeBits : ∀ width, CodeAccounting program width (encodedWordLiteral * width)`;
projected universally at `check.lean:46-54`. Expansions
`accounting_definition : CodeAccounting program width bits → bits = ((program.map (fun i => i.primitive.constants)).flatten).length * width`
and `encoded_length_definition : programWords program = ...` (`:40-44`).
Other consumers: `signed_order`, `signed_width`, `input_all_sizes`,
`oracle_header`, `oracle_missing_header`, `terminal_fault`, `terminal_halted`,
`replay_fake`, three oracle examples, four boundary examples, `conservative_step`.

`Prim` (13 constructors) with `Prim.constants` word counts: load 3, constant 3,
move 3, arithmetic 5 (tag, sub-tag, dst, lhs, rhs), comparison 5, jump 2,
jumpRegister 2, branchZero 3, halt 2, store 3, reserve 2, loadKey 3,
compareKey 4. `Category` (10): read, register, arithmetic, comparison, branch,
control, write, allocation, keyRead, oracleComparison.

`FullyChargedPackedQueryCapstone` (`Packed/Capstone.lean:20-119`), the future
REQ-PRE-JOIN consumer, 33 fields, all over `buildMemory xs`:
allocationResidualLittleO, completeResidualLittleO, widthBounds, dataCapacity,
completeCapacity, memoryWordsFit, allocationAddressesFit, programFieldsFit,
budgetExact (`queryBudget = 837572`), programLength, encodedProgramBound,
registerCount (8271), scratchCount (8274), unusedRegisters, validInputs,
natContract, leftmost, result, halt, invalidGuard, stepBound, categoryPartition,
finalStateFit, transitionSafety, prefixSafety, readWidth, positionalReadBacking,
orderedLogicalRefinement, logicalReadOnly, suppliedMemoryAgreement, specResult,
noFailedLoads, invalidGuardSteps.

## 10. Counterfactuals attempted and outcomes

| Counterfactual | Outcome |
| --- | --- |
| Program recovering n without the header load (`reserve`; `sub 1`) | Compiles; inhabits `ProgramContract` at literal pins; no rejection exists (P1-1) |
| Same program with cell 0 removed | Still runs, still yields n (probe theorem) |
| Same program in the comparison model | Yields 0 (extent 1): the leak is word-model-specific |
| Width-indexed family `B w` with uniform shape certified per member | Provable by `rfl` per member with literal numerals; only prose excludes (P1-2; not compiled, follows from `closed_uniform` and the `Nat` parameters) |
| Add an oracle arm to `Prim` | `bstep_reflects`/`semantics_cap` stay true; rejected only by firewall bytes/imports and arm inspection (CATALOGUE FK-2) |
| Three-primitive `loadKey; loadKey; compareKey` | Moves key order into a register: legitimate charged route; outside the cap-1 control's domain by design |
| Replace field with `True`, delete field, sibling substitution, alias, zero count, semantic import, evaluator byte change (the 18 registry cases) | All rejected at the pinned stage/line in my replay (section 11); the comment-only control accepted |
| Matcher: extra failing lines | Tolerated (`Contains`), observed in author C16 output (P3-1) |

## 11. Replay execution results (clean detached copy at the exact target)

Copy: `git clone --no-hardlinks` of the audit worktree into
`<worktree>/.lake/pre1-replay-copy`, `git checkout --detach c1c970b8bfbae03163633365e512d487ae1c98f2`,
`core.autocrlf=true`, `git status --porcelain` empty before and after every mode,
HEAD unchanged after every mode. All modes: `-LakePath C:/Users/poin/.elan/toolchains/leanprover--lean4---v4.22.0/bin/lake.exe`,
`-AdministrativeDeadlineSeconds 120`, `-SleeperDeadlineSeconds 45`; Lean modes also
`-DeadlineSeconds 600`. Platform Microsoft Windows NT 10.0.26200.0, pwsh 7.6.6.

| Mode | Result | Wall time | Notes |
| --- | --- | --- | --- |
| `-RegistrySelfTestOnly` | PASS, executed=0, registry=18 | 4.002 s | 7 registry corruptions + 9 matcher fixtures |
| `-SelectorBoundarySelfTestOnly` | PASS | 25.241 s | 9 child-script invocations: omitted selects 18, valid selects 1, empty/whitespace/malformed/unknown/zero/missing/duplicate rejected at pinned surfaces |
| `-DeadlineSelfTestOnly` | PASS | 50.888 s | deterministic plans, collection self-test, exit 23 + stderr preserved, owned descendant created and absent after 45 s timeout; ownership kill-on-close-job; POSIX branch unexecuted |
| `-StartupOnly` | PASS, executed=0 | 106.874 s | cold firewall/producer/consumer in the copy |
| `-OnlyCase C01_REFLECTION` | PASS, executed=1, exact restoration verified | 56.381 s | |
| full (no selector) | PASS, mode=full, executed=18, registry=18 | 667.335 s | 198 stages, 28 self-tests (7 registry, 9 matcher, 9 selector, 3 process); `report.json`: verdict PASS, baseline head = restored head = `c1c970b8...`, baseline status = restored status = empty, error empty; registry content hash `aaec37a6...`; runner raw hash `12bb6e8a...` (CRLF checkout; LF-normalized `b85ff767...` equals the committed pin) |
| PS5: `-RegistrySelfTestOnly`, `-SelectorBoundarySelfTestOnly` under Windows PowerShell 5.1.26100.9444 (copy, `C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe`) | PASS / PASS | 3.424 s / 27.202 s | executed=0, registry=18 in both; tree clean after; no Lean run under 5.1 (the full replay was run under pwsh 7.6.6 only) |

Full-run detail (my run, evidence directory
`.lake/pre1-replay-copy/.lake/preprocessing-contract-replay/20260912-124214-b0998bd032854ecdb456121132cfaf1c`).
Executed IDs, in order, equal the frozen expected list: C01_REFLECTION, C02_CAP,
C03_CONSTANTS, C04_HEADER, C05_POINTWISE, C06_ORACLE, C07_UNIFORM,
C08_STORE_VALUE, C09_FRESH_RESERVE, C10_CODE_ACCOUNTING, C11_FIELD_DELETE,
C12_FIELD_WEAKEN, C13_SIBLING, C14_ACCEPT_COMMENT, C15_CODE_ALIAS,
C16_CODE_COUNT, C17_FIREWALL_IMPORT, C18_PRIMITIVE_BYTES. Every case: verdict
PASS, restoration EXACT, three restore stages (firewall, producer, consumer) all
exit 0.

| Case | Failing stage (firewall then producer exit 0 where applicable) | Exit | Stage time | Observed surface line |
| --- | --- | --- | --- | --- |
| C01_REFLECTION | consumer | 1 | 4.80 s | `scripts/preprocessing_contract_check.lean:11:2: error: type mismatch` |
| C02_CAP | consumer | 1 | 4.87 s | `...check.lean:13:2: error: type mismatch` |
| C03_CONSTANTS | consumer | 1 | 4.89 s | `...check.lean:15:47: error: type mismatch` |
| C04_HEADER | consumer | 1 | 4.68 s | `...check.lean:21:2: error: type mismatch` |
| C05_POINTWISE | consumer | 1 | 4.86 s | `...check.lean:24:2: error: type mismatch` |
| C06_ORACLE | consumer | 1 | 4.92 s | `...check.lean:27:2: error: type mismatch` |
| C07_UNIFORM | consumer | 1 | 4.73 s | `...check.lean:29:2: error: type mismatch` |
| C08_STORE_VALUE | consumer | 1 | 4.93 s | `...check.lean:32:2: error: type mismatch` |
| C09_FRESH_RESERVE | consumer | 1 | 4.77 s | `...check.lean:35:2: error: type mismatch` |
| C10_CODE_ACCOUNTING | consumer | 1 | 5.41 s | `...check.lean:38:2: error: type mismatch` |
| C11_FIELD_DELETE | consumer | 1 | 4.79 s | `...check.lean:47:76: error: Invalid field 'uniform': The environment does not contain ...` |
| C12_FIELD_WEAKEN | consumer | 1 | 5.11 s | `...check.lean:47:76: error: type mismatch` |
| C13_SIBLING | consumer | 1 | 4.91 s | `...check.lean:27:2: error: type mismatch` (the sibling fact does not supply the oracle proposition) |
| C14_ACCEPT_COMMENT | consumer (accept control) | 0 | 4.81 s | `PRE1-CONTRACT-TYPED-CONSUMERS PASS` after firewall and producer exit 0 |
| C15_CODE_ALIAS | consumer | 1 | 4.81 s | `...check.lean:42:86: error: type mismatch` |
| C16_CODE_COUNT | consumer | 1 | 4.88 s | `...check.lean:44:94: error: type mismatch` |
| C17_FIREWALL_IMPORT | firewall (one compile stage only) | 1 | 3.03 s | `PRE1-FIREWALL imports rejected: RMQ/Core/WordRAM/Construction/Primitive.lean actual=[Std,RMQ.Core.Shape]` |
| C18_PRIMITIVE_BYTES | firewall (one compile stage only) | 1 | 3.50 s | `PRE1-FIREWALL frozen primitive bytes changed: RMQ/Core/WordRAM/Construction/Primitive.lean` |

Stage statistics of my run against the deadlines used: consumer n=35 max 5.85 s
(deadline 600), producer n=35 max 7.73 s (600), firewall n=37 max 4.58 s (120),
git head/status/worktree/index n=80 max 2.50 s (120), selector n=9 max 3.18 s
(120), known-failure 2.40 s (120), owned-descendant-timeout 45.15 s at 45 s
(the one intended timeout; the descendant was created and was absent
afterwards). Total stage time 656.639 s. No stage timed out or exceeded the
output limit. Deviations from the author run: none in verdicts or surfaces;
this run used a clean detached tree at the exact target (author baseline was
the dirty pre-commit tree at the base), pwsh 7.6.6 (author 7.6.5), deadlines
600/120/45 (author 120/60/30).

## 12. Evidence identity and tiers

Archives vs indexes (SHA-256 recomputed by me, uppercase, match unless noted):
`aggregate-gate.zip` E7019833...192B (2,488,373 bytes) = `archive-integrity.json`/`aggregate-summary.json`;
`gate-failure-diagnostics.zip` A7095868...9D58 = `archive-integrity.json`/`final-evidence-summary.json`;
`postgate-final-checks.zip` 890D595F...F486 = both;
`replay-full.zip` 2C27A217...6A12, `replay-inconclusive-startup.zip` F611F107...C2D6,
`deadline-margin-check.zip` 58564BF8...0084, `startup.zip` CF025162...6662,
`focused-C01.zip` 4A57AA1F...BD71, `ps7-registry-matcher.zip` FC01A943...BE14,
`ps7-selectors.zip` 4D518769...E3E, `ps7-deadline.zip` 0DFE2785...BE90,
`ps5-registry-matcher.zip` 4D8418A4...877C, `ps5-selectors.zip` 278E2095...2CC9
all = `REPLAY_INDEX.json`. `replay-full.zip` contains 198 `stage-*.json`, 18
`case-*.json`, `report.json` with `verdict PASS`, `mode full`, executed = expected =
18, registry `aaec37a6...`, runner `b85ff767...`.
Source hashes: the eleven `sourceHashes` in `replay-full-summary.json` and the
eleven `protectedSourceHashes` in `final-evidence-summary.json` equal my
CRLF-to-LF normalized hashes of the same eleven files at the target for all ten
text sources (`Primitive` 80120235..., `Input` 78316916..., `Model` 9d7b3d7e...,
`Controls` 8887604c..., `Conservative` e10276e6..., `Contract` d85498fc...,
`check.lean` 09cc8671..., `firewall.ps1` 1f6903d5..., `replay.ps1` b85ff767...,
`primitive_manifest.json` a1d31f0b...) and my raw hash for `lean-toolchain`
(ad3e6363...; the author tree evidently held LF Lean sources and a CRLF
toolchain file; my fresh checkout is CRLF throughout, so raw hashes differ and
normalized hashes agree). `primitive_manifest.json` hashes equal my normalized
hashes of the three roots. `scripts/gate.ps1` raw hash 5301D870...D5E4 equals
the `gateSha256` in `aggregate-summary.json` and the coordinator file. Registry
content hash matches (above). REPORT.md at the target: normalized
d9174ff1...1193 equals `final-evidence-summary.json.reportSha256` (13,120
normalized bytes; 13,331 raw CRLF).
Tiers: kernel theorems (tier 1) for every `ContractPrerequisites` field and
control; explicit-model theorems (tier 2) for the initial-state and bridge
facts; executable validation (tier 3) for the consumer elaboration, firewall and
replay; reproducible artifacts (tier 4) for the committed archives and this
audit's logs; process evidence (tier 5) for REPORT.md, DD/WDD entries and the
matrix appendices.

## 13. Known-status stage (consulted after independent conclusions and after the probe compiled)

`docs/internal/extensions/pre1/REPORT.md` (author): Status INCOMPLETE, Phase
AUTHOR_VERIFIED; AGGREGATE_FAILED; claims 18/18 replay, 198 stages, 28 self-tests,
the 12 s sleeper inconclusive attempt and 30 s repair, the failed first aggregate
(14,402.710 s, exit -1, two claim-policy fixture failures with empty output,
focused fixture reruns passing) and the nine standard-axiom prints. Every
checkable statement in it that I compared agrees with my independent
observations; it makes no claim that a builder exists or that any builder row is
closed. The report hash recorded in `final-evidence-summary.json`
(`reportSha256`) equals REPORT.md's LF-normalized hash at the target (section
12); the two are separate files, so no self-reference is involved.
`extension-coordination-20260911/pre1-review/aggregate-retry/result.json`
(coordinator, the single permitted file): unchanged `scripts/gate.ps1` (raw hash
5301D870..., matches) on exactly `c1c970b8...`, clean before and after, exit 0,
9,678.093 s, `GATE COVERAGE: 18 of 18 advertised checkers invoked`, `GATE PASS`,
no protected-file change. As stated in the prompt, this certifies the
repository-wide gate; because the roster does not include the PRE-1 firewall,
producer or consumer (P2-1), it is not evidence about the Construction modules,
whose evidence is the replay and this audit's builds.
Candidate public prose in the delta (`docs/FAMILY_SUMMARY.md` +12,
`docs/DIGESTION_LOG.md` +21, `DESIGN_DECISIONS.md` +12 DD-20260912-PRE1-001,
`WORKFLOW_DESIGN_DECISIONS.md` +74 WDD-20260912-PRE1-001/002): each states that
the builder, linear bounds and capstone remain unproved and that existing
paper/headline identities are unchanged; I found no overclaim. One sentence in
DIGESTION_LOG ("Length must be read from cell zero") describes the intent, not a
checked property of programs (P1-1).

## 14. Commands, durations, exits, and unavailable checks

Heavy commands (one Lean/Lake process at a time in this tree; `LEAN_NUM_THREADS=1`):

| # | Command (cwd) | Duration | Exit |
| --- | --- | --- | --- |
| H1a | `lake.exe build -j1 RMQ.Core.WordRAM.Construction.Contract` (audit worktree) | 0.274 s | 1 ("unknown short option '-j'") |
| H1b | `lake.exe build RMQ.Core.WordRAM.Construction.Contract` (audit worktree, cold) | 77.207 s | 0 |
| H1c | `lake.exe env lean scripts/preprocessing_contract_check.lean` (audit worktree) | 2.670 s | 0 |
| H2 | `lake.exe env lean <scratchpad>/HeaderLeakProbe.lean` (audit worktree; first attempt 3.295 s exit 1 with two unsolved `Fin` coercion goals, fixed by two `rfl` lemmas) | 2.272 s | 0 |
| H3 | replay `-StartupOnly` (copy, cold) | 106.874 s | 0 |
| H4 | replay `-OnlyCase C01_REFLECTION` (copy) | 56.381 s | 0 |
| H5 | replay full 18 (copy; runner serializes its own Lean/Lake stages with `LEAN_NUM_THREADS=1`) | 667.335 s | 0 |

Light commands: preflight 3.807 s exit 0; `git clone --no-hardlinks` 14.033 s;
replay self-test modes (section 11); rg scans (exit 1 = no matches, expected);
Python byte comparison of the matrix; hash recomputations; `Expand-Archive` of
`replay-full.zip`.

Unavailable or not run, and why: POSIX/WSL branch of `owned_process_tree.ps1`
(host is Windows; recorded as unexecuted by the runner itself); full default
`lake build` and `scripts/gate.ps1` (coordinator-owned; already PASSED on this
commit per the permitted result file, and would not reach the new modules);
any build in the author worktree (forbidden); a second full replay under Windows
PowerShell 5.1 (only the registry and selector self-test modes were run under
5.1; section 11). Setup notes: `-j1` is not accepted by the pinned Lake; the
elan proxy `lake.exe` on PATH is not used (explicit toolchain binary throughout).

## 15. Proof digestion

Conceptual change. Before any preprocessing algorithm is written, the project
fixes what one machine step may do (thirteen scalar primitives over 32-bit
encoded operands, one reservation creates one absent cell, one store
initializes one cell), where input may enter (an unsigned header cell and
pointwise biased-signed key cells, or an explicitly separate key oracle with
charged reads and comparisons), and what a certificate must expose (ten
prerequisite facts and a four-field program schema, each projected by an
independent consumer that a replay shows is load-bearing).

Plain English. The contract phase proves the small facts that make the later
big theorem non-vacuous: the evaluator cannot quietly compute a Cartesian shape
in one step; a program that changes with the input is not one program; a
reserved cell is empty until written; a store writes the register it says it
writes; the header instruction really loads the length and really faults when
the header is gone. It does not build anything.

Live assumptions. Indexed RAM access as mathematical functions (no Lean-runtime
claim); the accepted PQ1 arithmetic set with unbounded-`Nat` denotation until a
per-transition safety predicate is proved; `SignedFits`/`InputFits` premises for
the finite-key corollary; the comparison-oracle model for arbitrary `Int`; a
common logarithmic width to be instantiated at `wordWidth xs.length`.

Named downstream consumers. `PackedConstruction.efficientBuild_eq_buildMemory :
∀ xs, efficientBuild xs = PackedWordRAM.buildMemory xs` (does not exist yet) and
`PackedConstruction.constructionAndQueryCapstone_holds` (does not exist yet),
which must rewrite `fullyChargedPackedQueryCapstone_holds` along that equality
and add linear work, peak temporary words, safety and provenance over the same
run.

Skeptical graduate-student question. "Show me the one parameterless program,
show me that its first memory read is the header and that the emitted list is
literally the cells it wrote, and then show me a single theorem in which the
work count, the width bound and the query all mention that same run." The four
required amendments are exactly the places where the present contract would let
someone answer with a different object.

## 16. Roadmap alignment, best next target, durable path

Letter: the contract phase satisfies REQ-PRE-CONTRACT's clauses with the
amendments recorded; the three REPLAY rows are met on Windows; the historical
plan's C.3 freeze order is honoured by this audit. Spirit: the phase removes the
green-artifact defect class from the primitive layer but leaves four prose-only
guards at the run layer; making them checked (A1-A3) and gate-reached (A4) is
cheap and should precede builder authorization. Best next target for the
coordinator: impose A1-A4 as an append-only amendment ledger entry plus the
schema/registry/gate edits, then authorize the builder with the builder-phase
replay cases named in A1 and A2 pre-registered. Durable path of this report:
`docs/internal/audit_reports/2026-09-12_PRE1_contract_fresh_blind.md`
(uncommitted in the audit worktree; all inspected source equals the exact
target).

## 17. Report-sensitive checks (run after this report was persisted)

Run from the audit worktree with this file present as the only untracked
tracked-scope change; outcomes are appended below exactly as observed. The
claim-drift scanner excludes `docs/internal/audit_reports/**` by design
(`claim_drift_scan.ps1:305, 333`), so a strict PASS certifies the rest of the
tree with the report present, not the report's own prose; this report uses no
prohibited public-claim vocabulary as fact and paraphrases counterexamples.

Invalid first attempt (recorded, not counted). A detached wrapper launched at
12:56 named its argument parameter `$args`, a PowerShell automatic variable, so
every child started with no arguments: the two `pwsh` children idled to their
900 s and 600 s deadlines and the three `git` children printed help (exit 1).
No check executed in that attempt; its receipts are kept as
`final-checks.log` in the session scratchpad.

Pass 1 (corrected wrapper `final_checks2.ps1 -Pass pass1`, 16:46:26-16:47:07,
on the persisted report at 85,802 bytes, SHA-256
CB20FFFBD8F3B7E016276449187F8E330E9D9BD9859C836D159BEE0016655FB0; worktree
status before and after: only `?? docs/internal/audit_reports/2026-09-12_PRE1_contract_fresh_blind.md`;
HEAD `c1c970b8...`):

| Check | Command (cwd = audit worktree) | Deadline | Duration | Exit | Outcome |
| --- | --- | --- | --- | --- | --- |
| Strict claim scan | `pwsh -NoProfile -ExecutionPolicy Bypass -File scripts/claim_drift_scan.ps1 -Strict` | 900 s | 33.042 s | 0 | `CLAIM-DRIFT: scan complete (1577 hits, 0 strict failures)`; no allowlist or policy touched |
| Strict design check against the exact base | `pwsh ... -File scripts/design_decision_check.ps1 -Strict -Base 0e6a00f654abc64f8b68988fa9675b9a839dca2f` | 600 s | 1.956 s | 0 | `DESIGN-CHECK: checked 64 changed files (8 code, 53 workflow, 4 neutral)`; no ledger edit demanded, so no out-of-scope conflict arose |
| Strict claim scan over this report as a process record | `pwsh ... -File scripts/claim_drift_scan.ps1 -Strict -IncludeProcessRecords -Path docs/internal/audit_reports/2026-09-12_PRE1_contract_fresh_blind.md` | 900 s | 3.404 s | 0 | `CLAIM-DRIFT: scan complete (11 hits, 0 strict failures)`; all 11 hits are `[review]`-labelled historical-term matches on lines quoting the timing `77.207 s` and the `:47:76` consumer surface, none strict |
| Whitespace, working tree | `git diff --check` | 120 s | 0.129 s | 0 | clean |
| Whitespace, index | `git diff --cached --check` | 120 s | 0.137 s | 0 | clean |
| Whitespace, this untracked report | `git diff --no-index --check <empty file> docs/internal/audit_reports/2026-09-12_PRE1_contract_fresh_blind.md` | 120 s | 0.131 s | 1 | no whitespace error printed; exit 1 is `--no-index`'s differences-exist code; stderr carried only Git's LF-to-CRLF normalization notice for this LF-authored file |

Pass 2. Recording pass 1 above changes this file's bytes, so the two
report-sensitive checks that read this file (`-IncludeProcessRecords -Path`
strict scan and the `--no-index --check`) plus `git diff --check` are re-run
on the exact final bytes after this section is written; their receipts are
`final-checks-pass2.log` and `final-pass2-*.stdout` in the session scratchpad,
and the final byte length and SHA-256 reported to the coordinator are those of
the file that pass 2 scanned. No further edit follows pass 2.
