$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $env:PRE1_GATE_ROOT
[Environment]::CurrentDirectory = $env:PRE1_GATE_ROOT
$pre1GateExit = 1
Start-Transcript -LiteralPath (Join-Path $env:PRE1_GATE_LOG 'gate.transcript.txt') | Out-Null
try {
  $pre1ActualLake = (Get-Command lake -CommandType Application | Select-Object -First 1).Source
  if ([IO.Path]::GetFullPath($pre1ActualLake) -ine [IO.Path]::GetFullPath($env:PRE1_GATE_LAKE)) { throw "Wrong Lake executable: $pre1ActualLake" }
  Remove-Variable LASTEXITCODE -Scope Global -ErrorAction SilentlyContinue
  & (Join-Path $env:PRE1_GATE_ROOT 'scripts/gate.ps1')
  $pre1GateExit = [int](Get-Variable LASTEXITCODE -ErrorAction Stop).Value
} finally {
  Stop-Transcript | Out-Null
}
exit $pre1GateExit
