$ErrorActionPreference = 'Stop'
$pre1Root = 'C:/Users/poin/.codex/worktrees/2fb8/RMQ'
$pre1Bin = 'C:/Users/poin/.elan/toolchains/leanprover--lean4---v4.22.0/bin'
$pre1Sha = '26d6b5c2b10ed06ae4f72d9075d746ede987bdab'
$pre1Run = Join-Path $pre1Root ('.lake/pre1-aggregate/' + $pre1Sha)
$pre1Utf8 = [Text.UTF8Encoding]::new($false)
Set-Location -LiteralPath $pre1Root
[Environment]::CurrentDirectory = $pre1Root
. (Join-Path $pre1Root 'scripts/owned_process_tree.ps1')
$pre1Head = @(& git rev-parse HEAD)
if ($LASTEXITCODE -ne 0 -or $pre1Head.Count -ne 1 -or $pre1Head[0] -cne $pre1Sha) { throw 'Aggregate HEAD changed' }
$pre1Status = @(& git status --porcelain=v1 --untracked-files=all)
if ($LASTEXITCODE -ne 0 -or $pre1Status.Count -ne 0) { throw 'Aggregate requires a clean tree' }
$pre1Launch = [ordered]@{
  sourceCommit=$pre1Sha; cleanBefore=$true; gitStatus=$pre1Status
  startedUtc=[DateTime]::UtcNow.ToString('o'); platform=[Environment]::OSVersion.ToString(); powershell=$PSVersionTable.PSVersion.ToString()
  registryContentSha256='aaec37a62bc74b483d09362a5d16f62afc2ae3a7be007577bc13e4c87c98574e'
  runnerSha256=(Get-FileHash (Join-Path $pre1Root 'scripts/preprocessing_contract_replay.ps1') -Algorithm SHA256).Hash.ToLowerInvariant()
  gateSha256=(Get-FileHash (Join-Path $pre1Root 'scripts/gate.ps1') -Algorithm SHA256).Hash.ToLowerInvariant()
  primitiveManifestSha256=(Get-FileHash (Join-Path $pre1Root 'docs/internal/extensions/pre1/primitive_manifest.json') -Algorithm SHA256).Hash.ToLowerInvariant()
  driverSha256=(Get-FileHash (Join-Path $pre1Run 'gate-driver.ps1') -Algorithm SHA256).Hash.ToLowerInvariant()
  deadlineSeconds=14400; outputLimitBytes=268435456; leanNumThreads=1; lake=(Join-Path $pre1Bin 'lake.exe')
  command='pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File gate-driver.ps1 -> unchanged scripts/gate.ps1'
}
[IO.File]::WriteAllText((Join-Path $pre1Run 'launch.json'), ($pre1Launch | ConvertTo-Json -Depth 8), $pre1Utf8)
$pre1Result = Invoke-RMQOwnedBoundedProcess -FilePath (Get-Process -Id $PID).Path -Arguments @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $pre1Run 'gate-driver.ps1')) -WorkingDirectory $pre1Root -Stage 'pre1-aggregate' -DeadlineSeconds 14400 -OutputLimitBytes 268435456 -TempRoot (Join-Path $pre1Run 'owned') -Environment @{
  PATH=$pre1Bin + [IO.Path]::PathSeparator + $env:PATH
  LEAN_NUM_THREADS='1'; PRE1_GATE_ROOT=$pre1Root; PRE1_GATE_LOG=$pre1Run; PRE1_GATE_LAKE=(Join-Path $pre1Bin 'lake.exe')
}
[IO.File]::WriteAllText((Join-Path $pre1Run 'gate.result.json'), ($pre1Result | ConvertTo-Json -Depth 12), $pre1Utf8)
[IO.File]::WriteAllLines((Join-Path $pre1Run 'gate.stdout.log'), [string[]]$pre1Result.StandardOutput, $pre1Utf8)
[IO.File]::WriteAllLines((Join-Path $pre1Run 'gate.stderr.log'), [string[]]$pre1Result.StandardError, $pre1Utf8)
$pre1AfterHead = @(& git rev-parse HEAD)
$pre1AfterStatus = @(& git status --porcelain=v1 --untracked-files=all)
$pre1Post = [ordered]@{ endedUtc=[DateTime]::UtcNow.ToString('o'); head=$pre1AfterHead; status=$pre1AfterStatus; cleanAfter=($LASTEXITCODE -eq 0 -and $pre1AfterStatus.Count -eq 0 -and $pre1AfterHead.Count -eq 1 -and $pre1AfterHead[0] -ceq $pre1Sha); result=@{ exit=$pre1Result.ExitCode; durationSeconds=$pre1Result.DurationSeconds; timedOut=$pre1Result.TimedOut; outputLimitExceeded=$pre1Result.OutputLimitExceeded; ownership=$pre1Result.Ownership; terminatedIds=$pre1Result.TerminatedIds } }
[IO.File]::WriteAllText((Join-Path $pre1Run 'postflight.json'), ($pre1Post | ConvertTo-Json -Depth 8), $pre1Utf8)
$pre1Post | ConvertTo-Json -Depth 8
if ($pre1Result.TimedOut -or $pre1Result.OutputLimitExceeded -or $pre1Result.ExitCode -ne 0 -or $pre1Result.StandardOutput -cnotcontains 'GATE PASS' -or -not $pre1Post.cleanAfter) { throw 'Aggregate certification failed; inspect preserved evidence.' }
Write-Host 'PRE1 AGGREGATE CERTIFICATION PASS'
