param([switch]$LeanOnly, [switch]$DocsOnly)
$ErrorActionPreference = 'Stop'
$pre1Root = 'C:/Users/poin/.codex/worktrees/2fb8/RMQ'
$pre1Sha = '26d6b5c2b10ed06ae4f72d9075d746ede987bdab'
$pre1Base = '0e6a00f654abc64f8b68988fa9675b9a839dca2f'
Set-Location -LiteralPath $pre1Root
[Environment]::CurrentDirectory = $pre1Root
$pre1Post = Get-Content (Join-Path $pre1Root ".lake/pre1-aggregate/$pre1Sha/postflight.json") -Raw | ConvertFrom-Json
if (-not $pre1Post.cleanAfter -or $pre1Post.head[0] -cne $pre1Sha) { throw 'Gate restoration requires diagnosis before further checks' }
$pre1Cleanup = Get-Content (Join-Path $pre1Root ".lake/pre1-aggregate/$pre1Sha/cleanup-verification.json") -Raw | ConvertFrom-Json
if (-not $pre1Cleanup.allAbsent) { throw 'Owned process cleanup has not been confirmed' }
. (Join-Path $pre1Root 'scripts/owned_process_tree.ps1')
$pre1Run = Join-Path $pre1Root '.lake/pre1-postgate-checks'
[void](New-Item -ItemType Directory -Path $pre1Run -Force)
$pre1Shell = (Get-Process -Id $PID).Path
$pre1Git = (Get-Command git -CommandType Application | Select-Object -First 1).Source
$pre1Rg = (Get-Command rg -CommandType Application | Select-Object -First 1).Source
$pre1Lake = 'C:/Users/poin/.elan/toolchains/leanprover--lean4---v4.22.0/bin/lake.exe'
$pre1Tests = @()
if (-not $DocsOnly) {
  $pre1Tests += @{ name='contract-build'; file=$pre1Lake; args=@('build','RMQ.Core.WordRAM.Construction.Contract'); exit=0 }
  $pre1Tests += @{ name='contract-consumer'; file=$pre1Lake; args=@('env','lean','scripts/preprocessing_contract_check.lean'); exit=0 }
}
if (-not $LeanOnly) {
  $pre1Tests += @{ name='design-source-commit'; file=$pre1Shell; args=@('-NoProfile','-File','scripts/design_decision_check.ps1','-Strict','-Base',$pre1Base,'-Head',$pre1Sha); exit=0 }
  $pre1Tests += @{ name='design-report-tree'; file=$pre1Shell; args=@('-NoProfile','-File','scripts/design_decision_check.ps1','-Strict','-Base',$pre1Sha); exit=0 }
  $pre1Tests += @{ name='claim-report-tree'; file=$pre1Shell; args=@('-NoProfile','-File','scripts/claim_drift_scan.ps1','-Strict'); exit=0 }
  $pre1Tests += @{ name='trust-hygiene'; file=$pre1Rg; args=@('-n','\b(sorry|admit|axiom|unsafe|opaque|implemented_by|partial|extern|noncomputable)\b|import Mathlib','RMQ','lakefile.toml'); exit=1 }
  $pre1Tests += @{ name='reduction-hygiene'; file=$pre1Rg; args=@('-n','native_decide|Lean\.ofReduceBool','RMQ'); exit=1 }
  $pre1Tests += @{ name='whitespace-working'; file=$pre1Git; args=@('diff','--check'); exit=0 }
  $pre1Tests += @{ name='whitespace-staged'; file=$pre1Git; args=@('diff','--cached','--check'); exit=0 }
  $pre1Tests += @{ name='whitespace-source-commit'; file=$pre1Git; args=@('diff','--check',$pre1Base,$pre1Sha); exit=0 }
}
$pre1Utf8 = [Text.UTF8Encoding]::new($false)
foreach ($pre1Test in $pre1Tests) {
  $pre1Result = Invoke-RMQOwnedBoundedProcess -FilePath $pre1Test.file -Arguments $pre1Test.args -WorkingDirectory $pre1Root -Stage $pre1Test.name -DeadlineSeconds 120 -OutputLimitBytes 67108864 -TempRoot (Join-Path $pre1Run 'owned') -Environment @{LEAN_NUM_THREADS='1'}
  $pre1Record = [pscustomobject]@{ command=$pre1Test.file; arguments=$pre1Test.args; expectedExit=$pre1Test.exit; sourceCommit=$pre1Sha; reportSha256=(Get-FileHash -LiteralPath 'docs/internal/extensions/pre1/REPORT.md' -Algorithm SHA256).Hash.ToLowerInvariant(); reportBytes=(Get-Item -LiteralPath 'docs/internal/extensions/pre1/REPORT.md').Length; result=$pre1Result }
  [IO.File]::WriteAllText((Join-Path $pre1Run ($pre1Test.name + '.json')), ($pre1Record | ConvertTo-Json -Depth 12), $pre1Utf8)
  Write-Host ($pre1Test.name + ': exit=' + $pre1Result.ExitCode + ', seconds=' + $pre1Result.DurationSeconds)
  if ($pre1Result.TimedOut -or $pre1Result.OutputLimitExceeded -or $pre1Result.ExitCode -ne $pre1Test.exit) { throw ('Check failed: ' + $pre1Test.name) }
}
$pre1Summary = Get-Content docs/internal/extensions/pre1/evidence/replay-full-summary.json -Raw | ConvertFrom-Json
$pre1Hashes = @($pre1Summary.sourceHashes | ForEach-Object { $pre1Actual=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant(); [pscustomobject]@{path=$_.path; expected=$_.sha256; actual=$pre1Actual; match=($pre1Actual -ceq $_.sha256)} })
[IO.File]::WriteAllText((Join-Path $pre1Run 'source-hashes.json'), ($pre1Hashes | ConvertTo-Json -Depth 5), $pre1Utf8)
if (@($pre1Hashes | Where-Object { -not $_.match }).Count -ne 0) { throw 'PRE source changed after author replay' }
Write-Host 'PRE1 POSTGATE CHECKS PASS'
