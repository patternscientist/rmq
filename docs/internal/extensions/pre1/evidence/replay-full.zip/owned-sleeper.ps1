$shell = (Get-Process -Id $PID).Path
$options = @{ FilePath = $shell; ArgumentList = @('-NoLogo', '-NoProfile', '-Command', 'Start-Sleep -Seconds 120'); PassThru = $true }
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) { $options.WindowStyle = 'Hidden' }
$child = Start-Process @options
[IO.File]::WriteAllText('C:\Users\poin\.codex\worktrees\2fb8\RMQ\.lake\preprocessing-contract-replay\20260912-011044-6a87f7de7fdc463d89d0d35821e9e029\owned-descendant.pid', [string]$child.Id)
Start-Sleep -Seconds 120