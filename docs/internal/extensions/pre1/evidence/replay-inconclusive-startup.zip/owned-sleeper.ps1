$shell = (Get-Process -Id $PID).Path
$options = @{ FilePath = $shell; ArgumentList = @('-NoLogo', '-NoProfile', '-Command', 'Start-Sleep -Seconds 120'); PassThru = $true }
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) { $options.WindowStyle = 'Hidden' }
$child = Start-Process @options
[IO.File]::WriteAllText('C:\Users\poin\.codex\worktrees\2fb8\RMQ\.lake\preprocessing-contract-replay\20260912-010514-43a6110df1e54d41bb8364ddd5b420af\owned-descendant.pid', [string]$child.Id)
Start-Sleep -Seconds 120