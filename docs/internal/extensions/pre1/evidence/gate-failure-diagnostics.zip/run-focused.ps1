$ErrorActionPreference = 'Stop'
$pre1Root = 'C:/Users/poin/.codex/worktrees/2fb8/RMQ'
$pre1Sha = '26d6b5c2b10ed06ae4f72d9075d746ede987bdab'
Set-Location -LiteralPath $pre1Root
[Environment]::CurrentDirectory = $pre1Root
$pre1Post = Get-Content (Join-Path $pre1Root ".lake/pre1-aggregate/$pre1Sha/postflight.json") -Raw | ConvertFrom-Json
if (-not $pre1Post.cleanAfter -or $pre1Post.head[0] -cne $pre1Sha) { throw 'Gate did not restore the clean frozen source' }
. (Join-Path $pre1Root 'scripts/owned_process_tree.ps1')
$pre1Run = Join-Path $pre1Root '.lake/pre1-gate-failure-checks'
[void](New-Item -ItemType Directory -Path $pre1Run -Force)
$pre1Shell = (Get-Process -Id $PID).Path
$pre1Utf8 = [Text.UTF8Encoding]::new($false)
$pre1Tests = @(
  @{ name='preflight'; args=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/project_skill_preflight.ps1','-GovernanceRef','0e6a00f654abc64f8b68988fa9675b9a839dca2f','-RequiredSkills','rmq-proof-sprint','-RuntimeProjectSkills','rmq-audit-prompt,rmq-coordinator,rmq-proof-sprint') },
  @{ name='family-three-constructor'; args=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/claim_drift_policy_regression.ps1','-OnlyCase','r1r2-48147cb-family-three-constructor-vocabulary') },
  @{ name='former-allowance-unqualified'; args=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/claim_drift_policy_regression.ps1','-OnlyCase','m1r5r4-former-allowance-unqualified-rejected') }
)
foreach ($pre1Test in $pre1Tests) {
  $pre1Result = Invoke-RMQOwnedBoundedProcess -FilePath $pre1Shell -Arguments $pre1Test.args -WorkingDirectory $pre1Root -Stage $pre1Test.name -DeadlineSeconds 120 -OutputLimitBytes 67108864 -TempRoot (Join-Path $pre1Run 'owned') -Environment @{LEAN_NUM_THREADS='1'}
  $pre1Record = [pscustomobject]@{ command=$pre1Shell; arguments=$pre1Test.args; expectedExit=0; sourceCommit=$pre1Sha; result=$pre1Result }
  [IO.File]::WriteAllText((Join-Path $pre1Run ($pre1Test.name + '.json')), ($pre1Record | ConvertTo-Json -Depth 12), $pre1Utf8)
  Write-Host ($pre1Test.name + ': exit=' + $pre1Result.ExitCode + ', seconds=' + $pre1Result.DurationSeconds)
  $pre1Result.StandardOutput | Select-Object -Last 5
  if ($pre1Test.name -eq 'preflight' -and ($pre1Result.TimedOut -or $pre1Result.OutputLimitExceeded -or $pre1Result.ExitCode -ne 0)) { throw 'Preflight failed; no focused checks authorized under mismatched governance' }
}
Write-Host 'PRE1 FOCUSED DIAGNOSTIC CHECKS FINISHED; inspect each verdict separately'
