# PRE-1 read-only aggregate failure diagnosis

Frozen source: 26d6b5c2b10ed06ae4f72d9075d746ede987bdab.
Governance base: 0e6a00f654abc64f8b68988fa9675b9a839dca2f.

The running aggregate reported two failed claim-policy fixtures:

- r1r2-48147cb-family-three-constructor-vocabulary (stdout line 8576).
- m1r5r4-former-allowance-unqualified-rejected (stdout line 8599).

The regression's final result is two fixture failures; its final tracked-state
restoration control passed. The gate recorded the regression's exit 1 as a
GATE ISSUE. Later successful checks cannot change that result.

Independent read-only author assistance from contract_inventory inspected the
isolated fixture and production paths without changing files or running a
scanner, Lean or Lake. The fixture at claim_drift_policy_regression.ps1:275
writes a literal sentence into a temporary docs/FAMILY_SUMMARY.md. It does not
read PRE-1's repository FAMILY_SUMMARY.md. The target regex matches that
literal, its allowance regex does not, and its path is in the current-fact
scope. The scanner, policy and regression source are unchanged between the
governance base and the frozen source commit.

Neither failure is followed by captured scanner output. Normal completion of
the scanner emits a final line. The inherited wrapper has a 30-second child
timeout, while its failure reporter (around line 883) omits returned Code,
TimedOut and Cleaned fields. Per-case receipts and the overwritten temporary
fixture are not retained. Empty child output is consistent with an execution
or timeout failure; the cause is not established by the preserved evidence.
No semantic checker defect or PRE-1 document interaction has been demonstrated.

The smallest existing diagnostic is one invocation of the unchanged regression
with -OnlyCase for each exact ID above, after the aggregate and its restoration
have completed. Expected rejection and the child timeout remain unchanged.
Outer command, duration, exit, timeout, stdout and stderr will be retained.
Focused success is diagnostic evidence only, not an aggregate pass or permission
to start the builder. Shared checker changes and any new aggregate scheduling
belong to coordinator follow-up.
